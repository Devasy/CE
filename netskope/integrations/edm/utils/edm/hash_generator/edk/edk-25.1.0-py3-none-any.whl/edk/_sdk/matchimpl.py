###
# Copyright 2023 Open Text.
# 
# The only warranties for products and services of Open Text and its
# affiliates and licensors ("Open Text") are as may be set forth in the
# express warranty statements accompanying such products and services.
# Nothing herein should be construed as constituting an additional warranty.
# Open Text shall not be liable for technical or editorial errors or omissions
# contained herein. The information contained herein is subject to change
# without notice.
# 
# Except as specifically indicated otherwise, this document contains
# confidential information and a valid license is required for possession, use
# or copying. If this work is provided to the U.S. Government, consistent with
# FAR 12.211 and 12.212, Commercial Computer Software, Computer Software
# Documentation, and Technical Data for Commercial Items are licensed to the
# U.S. Government under vendor's standard commercial license.
###
__all__ = ['SimpleMatch',
           'ProxyMatchBytes', 'ProxyRepeatedMatchBytes',
           'ProxyMatchString', 'ProxyRepeatedMatchString']


from typing import Any, Iterator, Optional, Sequence, TYPE_CHECKING
from ..typehints import ComponentLike, MatchLike, StringLike, TablePosition
if TYPE_CHECKING:
    from ..sdk import EdkSession


class _ComponentBase:
    """ Provides common methods for Component classes """
    def asdict(self) -> dict[str,Any]:
        """A dictionary representing the component"""
        return {'name':self.name, 'text':self.text, 'offset':self.offset}

    def __str__(self) -> str:
        return str(self.asdict())

    def __repr__(self) -> str:
        return '<{}:{}={!r}>'.format('Component', self.name, self.text)


class _ComponentsBase:
    """ Provides common methods for Component-list classes """
    def __repr__(self) -> str:
        return '[{}]'.format(','.join(map(repr, self)))


class _MatchBase:
    """ Provides common methods for Match classes """
    def asdict(self, full:bool=False) -> dict[str,Any]:
        """A dictionary representing the match"""
        m = {'name': self.name, 'original': self.orig}
        if (normalized := self.text) != m['original'] or full:
            m['normalized'] = normalized
        m['offset'] = self.offset
        if (score := self.score) != 1.0 or full:
            m['score'] = score
        if (components := self.components):
            m['components'] = [c.asdict() for c in components]
        if (tpos := self.tablepos) is not None:
            m['table'] = {'row': tpos.row, 'col': tpos.col}
        if (tnum := self.tablenum) is not None:
            m.setdefault('table', {})['number'] = tnum
        return m

    def __str__(self) -> str:
        return str(self.asdict())

    def __repr__(self) -> str:
        return '<{}:{}@{}={!r}>'.format(type(self).__name__, self.name, self.offset, self.text)


class SimpleMatch(_MatchBase):
    """ Match wrapper that fetches all values from EDK at init time (via proxy class) """
    class Component(_ComponentBase):
        """ Single match component """
        __slots__ = ('name', 'text', 'offset')
        def __init__(self, other:ComponentLike[str]|ComponentLike[bytes]):
            self.name:StringLike = other.name
            self.text:StringLike = other.text
            self.offset = other.offset

    __slots__ = ('name', 'text', 'orig', 'score', 'offset', 'tablepos', 'tablenum', '_components')
    def __init__(self, other:MatchLike[str]|MatchLike[bytes]):
        self.name:StringLike = other.name
        self.text:StringLike = other.text
        self.orig:StringLike = other.orig
        self.score = other.score
        self.offset = other.offset
        self.tablepos = other.tablepos
        self.tablenum = other.tablenum
        self._components = None if not other.components else [self.Component(c) for c in other.components]

    @property
    def components(self) -> Sequence[Component]:
        """ Get all match components """
        return self._components if self._components is not None else []

    def persist(self) -> 'SimpleMatch':
        """ No-op, as this class is already persistent """
        return self


class _ProxyMatchBase(_MatchBase):
    """ Common base for transient Match wrappers that fetch values from EDK on demand """
    class Components(_ComponentsBase):
        """ Instantiated as match.components; subclass to extend nested Component class """
        class Component(_ComponentBase):
            """ Common base for transient Component wrappers that fetch values from EDK on demand """
            __slots__ = ('_session', 'index')
            def __init__(self, session:'EdkSession', index:int):
                self._session = session
                self.index = index

            @property
            def name(self) -> bytes:
                """ The name of the component """
                return self._session.current_match_component_name(self.index)
            @property
            def text(self) -> bytes:
                """ The captured component text """
                return self._session.current_match_component_text(self.index)

        __slots__ = ('_session',)
        def __init__(self, session:'EdkSession'):
            self._session = session

        def __len__(self) -> int:
            return self._session.current_match_component_count

        def __getitem__(self, key:int) -> ComponentLike[str]|ComponentLike[bytes]:
            if not isinstance(key, int):
                raise TypeError(f"Component index should be an integer (got: {key})")
            num = len(self)
            if key < 0:
                key = num + key
            if key < 0 or key >= num:
                raise IndexError("Component index out of range")
            return self.Component(self._session, key)

        def __iter__(self) -> Iterator[ComponentLike[str]|ComponentLike[bytes]]:
            for index in range(len(self)):
                yield self.Component(self._session, index)

    __slots__ = ('components',)
    def __init__(self, session:'EdkSession'):
        self.components = self.Components(session)

    @property
    def _session(self) -> 'EdkSession':
        return self.components._session

    def persist(self) -> SimpleMatch:
        """ Copy all properties, returning an object that can persist after the next call to GetNextMatch """
        return SimpleMatch(self)

    @property
    def name(self) -> bytes:
        """ The matched entity name """
        return self._session.current_match_entity_name
    @property
    def text(self) -> bytes:
        """ The normalized match text """
        return self._session.current_match_text
    @property
    def orig(self) -> bytes:
        """ The text originally matched in the input """
        return self._session.current_match_orig_text
    @property
    def score(self) -> float:
        """ The score given to the match """
        return self._session.current_match_score
    @property
    def tablepos(self) -> Optional[TablePosition]:
        """ The row+column number of the match, if in table mode """
        tablepos = TablePosition._make(self._session.current_match_table_position)
        return tablepos if (all(x >= 0 for x in tablepos)) else None
    @property
    def tablenum(self) -> Optional[int]:
        """ The sequential table number, if in table mode """
        n = self._session.current_match_table_number
        return n if (n >= 0) else None


class ProxyMatchBytes(_ProxyMatchBase):
    """ Return match values from EDK on demand; text is returned as bytes """
    __slots__ = ()
    class Components(_ProxyMatchBase.Components):
        """ Return components from EDK on demand; text is returned as bytes """
        __slots__ = ()
        class Component(_ProxyMatchBase.Components.Component):
            """ Return component values from EDK on demand; text is returned as bytes """
            __slots__ = ()
            @property
            def offset(self) -> int:
                """ The component offset into the match text, in bytes """
                return self._session.current_match_component_offset(self.index)

    @property
    def offset(self) -> int:
        """ The match's position in the input text, in bytes """
        return self._session.current_match_orig_offset


class ProxyRepeatedMatchBytes(ProxyMatchBytes):
    """ Return repeated match values from EDK on demand; text is returned as bytes """
    __slots__ = ()
    @property
    def offset(self) -> int:
        """ The match's position in the input text, in bytes """
        return self._session.current_repeated_match_byte_offset


class ProxyMatchString(_ProxyMatchBase):
    """ Return match values from EDK on demand; text is returned as strings """
    __slots__ = ()
    class Components(_ProxyMatchBase.Components):
        """ Return components from EDK on demand; text is returned as strings """
        __slots__ = ()
        class Component(_ProxyMatchBase.Components.Component):
            """ Return component values from EDK on demand; text is returned as strings """
            __slots__ = ()
            @property
            def name(self) -> str:
                """ The name of the component """
                return super().name.decode('utf-8')
            @property
            def text(self) -> str:
                """ The captured component text """
                return super().text.decode('utf-8')
            @property
            def offset(self) -> int:
                """ The component offset into the match text, in characters """
                return self._session.current_match_component_offset_length(self.index)
    @property
    def name(self) -> str:
        """ The matched entity name """
        return super().name.decode('utf-8')
    @property
    def text(self) -> str:
        """ The normalized match text """
        return super().text.decode('utf-8')
    @property
    def orig(self) -> str:
        """ The text originally matched in the input """
        return super().orig.decode('utf-8')
    @property
    def offset(self) -> int:
        """ The match's position in the input text, in characters """
        return self._session.current_match_orig_offset_length


class ProxyRepeatedMatchString(ProxyMatchString):
    """ Return repeated match values from EDK on demand; text is returned as strings """
    __slots__ = ()
    @property
    def offset(self) -> int:
        """ The match's position in the input text, in characters """
        return self._session.current_repeated_match_codepoint_offset
