###
# Copyright 2024 Open Text.
# 
# The only warranties for products and services of Open Text and its
# affiliates and licensors ("Open Text") are as may be set forth in the
# express warranty statements accompanying such products and services.
# Nothing herein should be construed as constituting an additional warranty.
# Open Text shall not be liable for technical or editorial errors or omissions
# contained herein. The information contained herein is subject to change
# without notice.
# 
# Except as specifically indicated otherwise, this document contains
# confidential information and a valid license is required for possession, use
# or copying. If this work is provided to the U.S. Government, consistent with
# FAR 12.211 and 12.212, Commercial Computer Software, Computer Software
# Documentation, and Technical Data for Commercial Items are licensed to the
# U.S. Government under vendor's standard commercial license.
###
import datetime
import numbers

from typing import TypeAlias


class EdkTimeInterval:
    """
    Parameterized annotation type to represent a time interval passed to the EDK library.
    Parameters are the underlying C numeric type and, optionally, granularity (defaults
    to 1 second).
    """
    second = datetime.timedelta(seconds=1)
    millisecond = datetime.timedelta(milliseconds=1)

    __cache = {}

    @staticmethod
    def _edk_time_interval(base, unit):
        class EdkTimeInterval(base):
            __name__ = 'EdkTimeInterval[{b},{u}]'.format(b=base.__name__,u=unit)
            __qualname__ = __name__
            value_annotation: TypeAlias = datetime.timedelta|numbers.Number
            @classmethod
            def from_param(cls, obj):
                if isinstance(obj, datetime.timedelta):
                    obj = int(obj / unit)
                elif isinstance(obj, numbers.Number) and not isinstance(obj, numbers.Integral):
                    obj = int(obj)
                return base.from_param(obj)
        return EdkTimeInterval

    def __class_getitem__(cls, items):
        if not isinstance(items, tuple):
            items = (items, cls.second)
        parameterized = cls.__cache.get(items)
        if not parameterized:
            parameterized = cls._edk_time_interval(*items)
            cls.__cache[items] = parameterized
        return parameterized
