###
# Copyright 2024 Open Text.
# 
# The only warranties for products and services of Open Text and its
# affiliates and licensors ("Open Text") are as may be set forth in the
# express warranty statements accompanying such products and services.
# Nothing herein should be construed as constituting an additional warranty.
# Open Text shall not be liable for technical or editorial errors or omissions
# contained herein. The information contained herein is subject to change
# without notice.
# 
# Except as specifically indicated otherwise, this document contains
# confidential information and a valid license is required for possession, use
# or copying. If this work is provided to the U.S. Government, consistent with
# FAR 12.211 and 12.212, Commercial Computer Software, Computer Software
# Documentation, and Technical Data for Commercial Items are licensed to the
# U.S. Government under vendor's standard commercial license.
###
from .types import *
from ._dll import edkdll as _dll
from . import engine

from ctypes import POINTER, c_char_p, c_void_p


class EdkFactoryHandle(c_void_p):
    """
    A handle to an EDK Factory.
    """


@_dll.export()
def EdkFactoryCreateWithLicenseKey(ppFactory: POINTER(EdkFactoryHandle), szLicenseKey: c_char_p) -> None:
    r"""  Application-defined callback function used with the :any:`EdkSetInputStream` function.
    
    :param bBuffer: [in/out] A text buffer of minimum length nSize*nCount which the function should populate with data from the stream.
    :param nSize: [in] Item size in bytes.
    :param nCount: [in] Maximum number of items to be read.
    :param hStream: [in] The stream handle passed to :any:`EdkSetInputStream`.
    :raises: The number of characters read from the stream and placed into bBuffer.
    .. note:: API users should provide implement this function and pass its address to :any:`EdkSetInputStream`.
             :any:`EdkInputProc` is called by the API whenever more data is required as a result of calling :any:`EdkGetNextMatch`.
    .. seealso:: :any:`EdkSetInputStream` :any:`EdkAddInputText`
     Creates an EDK engine factory.
    
    :param ppFactory: A pointer to an :any:`EdkFactoryHandle`. If the factory is created, the handle is set on return.
     If creation fails, the handle in NULL on exit, and an error code is returned.
    :param szLicenseKey: A string containing a :ref:`valid license key <licensekey>` for Eduction.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: A factory is the preferred way to create EDK engines.
    .. seealso:: :any:`EdkFactoryDestroy`
    
    """


@_dll.export()
def EdkFactoryDestroy(pFactory: EdkFactoryHandle) -> None:
    r"""  Destroys an EDK engine factory.
    
    :param pFactory: An :any:`EdkFactoryHandle` previously allocated by a successful call to :any:`EdkFactoryCreateWithLicenseKey`.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: Frees any allocated memory owned by the EDK factory.
     Engines created by a factory remain valid for use even after the factory is destroyed.
    .. seealso:: :any:`EdkFactoryCreateWithLicenseKey`
    
    """


@_dll.export()
def EdkFactoryMakeEngine(pFactory: EdkFactoryHandle, ppEngine: POINTER(engine.EdkEngineHandle)) -> None:
    r"""  Get a new EDK engine from a factory.
    
    :param pFactory: An :any:`EdkFactoryHandle` previously allocated by a call to :any:`EdkFactoryCreateWithLicenseKey`.
    :param ppEngine: A pointer to an :any:`EdkEngineHandle`. If the engine can be created, the handle is set on return.
     If no engine is created, the handle is set to NULL along with :any:`EdkException`.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: This call creates an unconfigured engine; resources/grammars need to be loaded explicitly with calls to
     :any:`EdkLoadResourceFile` or :any:`EdkLoadResourceBuffer`. Other factory functions can create and configure an engine.
     API users should create an engine prior to calling most other EDK API functions that extract entities.
     You can access the engine functionality through sessions. For more information, see the Eduction Programming Guide.
    .. seealso:: :any:`EdkEngineDestroy` :any:`EdkSessionCreate` :any:`EdkSessionDestroy` :any:`EdkFactoryMakeEngineFromConfigFile` :any:`EdkFactoryMakeEngineFromConfigBuffer`
    
    """


@_dll.export()
def EdkFactoryMakeEngineFromConfigFile(pFactory: EdkFactoryHandle, ppEngine: POINTER(engine.EdkEngineHandle), szConfigFilePath: c_char_p) -> None:
    r"""  Get a new EDK engine from a factory, configured using a config file.
    
    :param pFactory: An :any:`EdkFactoryHandle` previously allocated by a call to :any:`EdkFactoryCreateWithLicenseKey`.
    :param ppEngine: A pointer to an :any:`EdkEngineHandle`. If the engine can be created, the handle is set on return.
     If no engine is created, the handle is set to NULL along with :any:`EdkException`.
    :param szConfigFilePath: A string representing the path to an eduction config file.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: The config file can use the same settings as for processes like edktool and eductionserver.
     The license used to create the engine factory must cover the grammars and entities used in the config file.
     Once the engine is created, it can be used immediately to create sessions.
     Any post-processing tasks specified in the config file will be automatically configured in the engine.
    .. seealso:: :any:`EdkEngineDestroy` :any:`EdkFactoryMakeEngineFromConfigBuffer`
    
    """


@_dll.export()
def EdkFactoryMakeEngineFromConfigBuffer(pFactory: EdkFactoryHandle, ppEngine: POINTER(engine.EdkEngineHandle), szConfigBuffer: c_char_p) -> None:
    r"""  Get a new EDK engine from a factory, configured using an in-memory config.
    
    :param pFactory: An :any:`EdkFactoryHandle` previously allocated by a call to :any:`EdkFactoryCreateWithLicenseKey`.
    :param ppEngine: A pointer to an :any:`EdkEngineHandle`. If the engine can be created, the handle is set on return.
     If no engine is created, the handle is set to NULL along with :any:`EdkException`.
    :param szConfigBuffer: A string containing an eduction config in memory.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: The config can use the same settings as for processes like edktool and eductionserver.
     The license used to create the engine factory must cover the grammars and entities used in the config.
     Once the engine is created, it can be used immediately to create sessions.
     Any post-processing tasks specified in the config will be automatically configured in the engine.
    .. seealso:: :any:`EdkEngineDestroy` :any:`EdkFactoryMakeEngineFromConfigFile`
    
    """


@_dll.export(errhandler=True)
def EdkGetLastFactoryError(pFactory: EdkFactoryHandle) -> tuple[EdkError,c_char_p]:
    r"""  Returns the latest error code from this factory.
    
    :param pFactory: An :any:`EdkFactoryHandle` previously allocated by a successful call to :any:`EdkFactoryCreateWithLicenseKey`.
    :return: A tuple containing:
        A standard :any:`EdkError` value corresponding to the last error of the engine.
        A string buffer to hold the error message.
    
    """

