###
# Copyright 2023 Open Text.
# 
# The only warranties for products and services of Open Text and its
# affiliates and licensors ("Open Text") are as may be set forth in the
# express warranty statements accompanying such products and services.
# Nothing herein should be construed as constituting an additional warranty.
# Open Text shall not be liable for technical or editorial errors or omissions
# contained herein. The information contained herein is subject to change
# without notice.
# 
# Except as specifically indicated otherwise, this document contains
# confidential information and a valid license is required for possession, use
# or copying. If this work is provided to the U.S. Government, consistent with
# FAR 12.211 and 12.212, Commercial Computer Software, Computer Software
# Documentation, and Technical Data for Commercial Items are licensed to the
# U.S. Government under vendor's standard commercial license.
###
from typing import Optional

from .api import EdkError, EdkErrorCode


class EdkException(Exception):
    """
    Base class for exceptions thrown when an EDK API function returns an error status.

    Can catch all EDK errors with:

    .. code-block:: python

        except EdkException as edkexc:
            ...

    or deal with specific errors by catching the relevant derived class(es):

    .. code-block:: python

        except (EdkConfigErrorException, EdkEntityNotFoundException) as edkexc:
            ...

    In either case, `edkexc.code` will contain the returned EdkErrorCode value.

    Note that raising EdkException(code) will throw an instance of the relevant
    derived exception class associated with `code`.
    """

    _edk_exceptions = {}

    def __class_getitem__(cls, code:EdkErrorCode|EdkError):
        code = EdkErrorCode(code) #pylint: disable=no-value-for-parameter
        return cls._edk_exceptions[code.value]

    def __new__(cls, code:EdkErrorCode|EdkError, **kwargs):
        try:
            excp = super().__new__(cls[code])
        except (ValueError, KeyError):
            excp = super().__new__(EdkException)
            excp.code = code
        return excp

    def __init__(self, code:EdkErrorCode|EdkError, *,
                 fname:Optional[str]=None,
                 message:Optional[str]=None
                 ):
        msg = "EdkError {err!s}".format(err=code)
        if fname: msg += " returned by {fn}".format(fn=fname)
        if message: msg += ":\n\t{msg}".format(msg=message)
        super().__init__(msg)


class _SpecializedEdkException(EdkException):
    """ This exists to intercept __new__ and __init__ calls to derived classes """
    def __new__(cls, **_):
        return Exception.__new__(cls)
    def __init__(self, *_, **kwargs):
        super().__init__(self.code, **kwargs)


for e in EdkErrorCode:
    if e.is_success:
        continue
    name = e.original.replace('EdkError', 'Edk').replace('EdkErr', 'Edk').replace('_', '') + 'Exception'
    _derived = type(name, (_SpecializedEdkException,), {'code':e})
    EdkException._edk_exceptions[e.value] = globals()[name] = _derived


class EdkWarning(Warning):
    """Base class for warnings raised by EDK code"""


class EdkTimeOutWarning(EdkWarning):
    """Last operation timed out"""
