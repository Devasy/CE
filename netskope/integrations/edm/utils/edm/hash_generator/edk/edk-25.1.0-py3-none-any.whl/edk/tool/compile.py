###
# Copyright 2023 Open Text.
# 
# The only warranties for products and services of Open Text and its
# affiliates and licensors ("Open Text") are as may be set forth in the
# express warranty statements accompanying such products and services.
# Nothing herein should be construed as constituting an additional warranty.
# Open Text shall not be liable for technical or editorial errors or omissions
# contained herein. The information contained herein is subject to change
# without notice.
# 
# Except as specifically indicated otherwise, this document contains
# confidential information and a valid license is required for possession, use
# or copying. If this work is provided to the U.S. Government, consistent with
# FAR 12.211 and 12.212, Commercial Computer Software, Computer Software
# Documentation, and Technical Data for Commercial Items are licensed to the
# U.S. Government under vendor's standard commercial license.
###
import contextlib
import os.path

from ._base import EdkToolModuleBase

class Compile(EdkToolModuleBase):

    command = 'compile'
    aliases = ['c']
    help = 'Create Eduction ECR files'

    @classmethod
    def add_arguments(cls,  parser) -> None:
        super().add_arguments(parser)
        parser.add_argument('-i', '--inputfile', required=True, help='Input file')
        parser.add_argument('-o', '--outputfile', help='Output file')
        parser.add_argument('-c', '--compileconfig', help='Compilation configuration file (JSON)')

    def __init__(self, args) -> None:
        super().__init__(args)
        self.inputfile = args.inputfile
        self.outputfile = args.outputfile or (os.path.splitext(self.inputfile)[0] + '.ecr')
        self.configfile = args.compileconfig

    def run(self):
        with contextlib.ExitStack() as ctx:
            factory = ctx.enter_context(self.get_factory())
            engine = ctx.enter_context(factory.engine())
            engine.load(grammarpath=self.inputfile, configpath=self.configfile)
            engine.save(grammarpath=self.outputfile)


if __name__ == '__main__':
    Compile.main()
