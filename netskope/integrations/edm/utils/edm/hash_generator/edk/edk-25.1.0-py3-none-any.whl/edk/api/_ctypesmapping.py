###
# Copyright 2024 Open Text.
# 
# The only warranties for products and services of Open Text and its
# affiliates and licensors ("Open Text") are as may be set forth in the
# express warranty statements accompanying such products and services.
# Nothing herein should be construed as constituting an additional warranty.
# Open Text shall not be liable for technical or editorial errors or omissions
# contained herein. The information contained herein is subject to change
# without notice.
# 
# Except as specifically indicated otherwise, this document contains
# confidential information and a valid license is required for possession, use
# or copying. If this work is provided to the U.S. Government, consistent with
# FAR 12.211 and 12.212, Commercial Computer Software, Computer Software
# Documentation, and Technical Data for Commercial Items are licensed to the
# U.S. Government under vendor's standard commercial license.
###
import ctypes

from typing import Optional


# Map ctypes types to the Python type annotation of their .value
CTYPES_MAPPING = {
    ctypes.c_bool: bool,
    ctypes.c_char: bytes,
    ctypes.c_wchar: str,
    ctypes.c_byte: int,
    ctypes.c_ubyte: int,
    ctypes.c_short: int,
    ctypes.c_ushort: int,
    ctypes.c_int: int,
    ctypes.c_uint: int,
    ctypes.c_long: int,
    ctypes.c_ulong: int,
    ctypes.c_longlong: int,
    ctypes.c_ulonglong: int,
    ctypes.c_size_t: int,
    ctypes.c_ssize_t: int,
    ctypes.c_float: float,
    ctypes.c_double: float,
    ctypes.c_longdouble: float,
    ctypes.c_char_p: Optional[bytes],
    ctypes.c_wchar_p: Optional[str],
    ctypes.c_void_p: Optional[int],
}


def map_param_type(t):
    """Attempt to translate ctypes type to associated Python type"""
    return CTYPES_MAPPING.get(t, getattr(t, 'value_annotation', t))
