###
# Copyright 2024 Open Text.
# 
# The only warranties for products and services of Open Text and its
# affiliates and licensors ("Open Text") are as may be set forth in the
# express warranty statements accompanying such products and services.
# Nothing herein should be construed as constituting an additional warranty.
# Open Text shall not be liable for technical or editorial errors or omissions
# contained herein. The information contained herein is subject to change
# without notice.
# 
# Except as specifically indicated otherwise, this document contains
# confidential information and a valid license is required for possession, use
# or copying. If this work is provided to the U.S. Government, consistent with
# FAR 12.211 and 12.212, Commercial Computer Software, Computer Software
# Documentation, and Technical Data for Commercial Items are licensed to the
# U.S. Government under vendor's standard commercial license.
###
from .types import *
from ._dll import edkdll as _dll
from .annotations import EdkTimeInterval
from . import _stream

from ctypes import POINTER, c_char_p, c_double, c_int, c_size_t, c_uint32, c_uint64, c_void_p, py_object
from collections.abc import Callable


class EdkSessionHandle(c_void_p):
    """
    A handle to an EDK Session.
    """


@_dll.export()
def EdkSessionDestroy(pSession: EdkSessionHandle) -> None:
    r"""  Destroys an EDK session.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: Frees any allocated memory owned by the EDK session, and releases any resources it had opened.
    .. seealso:: :any:`EdkSessionCreate`
    
    """


@_dll.export()
def EdkSetInputStream(pSession: EdkSessionHandle, hStream: py_object, pInputProc: EdkInputProc) -> None:
    r"""  Defines the data input stream for a session.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :param hStream:   A handle to a readable stream (for example, a FILE pointer to an opened file).
    :param pInputProc: The stream read function (of type :any:`EdkInputProc`) to use. 
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: In a pull mode, a session can read the input data from an input stream defined by ``hStream`` and ``pInputProc``. 
             Whenever the session requires more input data, it will call the stream read function specified here, passing the input stream as an argument.
             This provides behavior similar to the standard ``fread`` function. Input data must be encoded in UTF-8.
             Once a stream has been set, it cannot be changed to another stream, nor can :any:`EdkAddInputText` be called.
    .. seealso:: :any:`EdkAddInputText`
    
    """


@_dll.export()
def EdkAddInputText(pSession: EdkSessionHandle, szBuffer: c_char_p, nSize: c_size_t, bFinal: EdkBool) -> None:
    r"""  Adds text input to a session.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :param szBuffer: A handle to an input text buffer. The buffer must be UTF-8 encoded.
    :param nSize: The size of the buffer.
    :param bFinal: A Boolean that when set to true indicates that no more input will be provided. A value of false indicates that there is more input to follow.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: In a push mode, a session is given the input text in chunks using :any:`EdkAddInputText` with ``bFinal`` set to true for the last buffer. Input data must be encoded in UTF-8.
    .. seealso:: :any:`EdkSetInputStream`
    
    """


@_dll.export()
def EdkResetInputText(pSession: EdkSessionHandle) -> None:
    r"""  Resets the text input to a session.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    
    """


@_dll.export()
def EdkAddTableCell(pSession: EdkSessionHandle, szBuffer: c_char_p, nSize: c_size_t, nColSpan: c_size_t, pOffset: POINTER(EdkOffset)) -> None:
    r"""  Adds table cell input to a session.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :param szBuffer: A handle to an input text buffer. The buffer must be UTF-8 encoded.
    :param nSize: The size of the buffer.
    :param nColSpan: The number of cells the buffer value 'spans'. Use 1 for the normal case. If this value is greater than 1, (N-1) empty cells are added as padding.
    :param pOffset: The global positioning for this cell. This affects the offset values for produced matches if set. Set to NULL if you don't care about tracking this.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: This can only be used if table mode is configured. The function will return EdkErrTableModeNotConfigured if this is not the case.
    .. seealso:: :any:`EdkEndTableRow`
    
    """


@_dll.export()
def EdkEndTableRow(pSession: EdkSessionHandle, bFinalRow: EdkBool) -> None:
    r"""  Ends the current table row in a session.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :param bFinalRow: Set this to true to indicate that no more row data will be provided. A value of false indicates there are more rows to follow.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: This can only be used if table mode is configured. The function will return EdkErrTableModeNotConfigured if this is not the case.
    .. seealso:: :any:`EdkAddTableCell`
    
    """


@_dll.export()
def EdkSessionSetUserParamValue(pSession: EdkSessionHandle, szKey: c_char_p, szValue: c_char_p) -> None:
    r"""  Adds the key/value pair to the user parameters set for this session. If the key already exists in the set, the value it maps to is overwritten with the new value.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :param szKey: The key to add.
    :param szValue: The value to add.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: The given key/value pair is passed through to the Lua post-processing scripts. All such pairs can be accessed in a script if a second argument is defined for the processmatch or
               processmatches function. You can use these to change the behavior of your script in some manner (e.g. define a scoring threshold dynamically).
    
    """


@_dll.export()
def EdkSessionSetMinScore(pSession: EdkSessionHandle, dScore: c_double) -> None:
    r"""  Sets the min score for this session.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :param dScore: The min score to use for this session.
    .. note:: This overrides the value obtained from the engine handle that was used to create this session.
    
    """


@_dll.export()
def EdkSessionSetPostProcessingThreshold(pSession: EdkSessionHandle, dThreshold: c_double) -> None:
    r"""  Sets the post-processing threshold for this session.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :param dThreshold: The post-processing threshold to use for this session.
    .. note:: This overrides the value obtained from the engine handle that was used to create this session.
    
    """


@_dll.export()
def EdkSessionSetMatchTimeoutPrecise(pSession: EdkSessionHandle, nTimeoutMilliseconds: EdkTimeInterval[c_uint32,EdkTimeInterval.millisecond]) -> None:
    r"""  Sets the (precise) match timeout for this session.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :param nTimeout: The match timeout to use for this session, in milliseconds.
    .. note:: This overrides the value obtained from the engine handle that was used to create this session.
    
    """


@_dll.export()
def EdkSessionSetRequestTimeoutPrecise(pSession: EdkSessionHandle, nTimeoutMilliseconds: EdkTimeInterval[c_uint32,EdkTimeInterval.millisecond]) -> None:
    r"""  Sets the (precise) request timeout for this session.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :param nTimeout: The request timeout to use for this session, in milliseconds.
    .. note:: This overrides the value obtained from the engine handle that was used to create this session.
    
    """


@_dll.export()
def EdkSessionSetStartTime(pSession: EdkSessionHandle, nStartTime: EdkEpochTimeMilliseconds) -> None:
    r"""  Sets the start time for this session.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :param nStartTime: The start time for this session, in epoch milliseconds.
    .. note:: The start time for a session determines its timeout behavior, with respect to its match and request timeout values.
    
    """


@_dll.export()
def EdkSessionSetMaxMatchesPerDoc(pSession: EdkSessionHandle, nMaxMatchesPerDoc: c_uint32) -> None:
    r"""  Sets the maximum number of matches per document for a session.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :param nMaxMatchesPerDoc: An integer denoting the maximum number of matches per document.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: When set to a positive integer, eduction will stop at that number of matches per document. The default value is zero, meaning no limit.
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer.
    .. seealso:: :any:`EdkSetMaxMatchesPerDoc` can set this for the engine.
    
    """


@_dll.export()
def EdkSessionSetEntityMatchLimit(pSession: EdkSessionHandle, szEntityName: c_char_p, nLimit: c_int) -> None:
    r"""  Sets the maximum number of matches for an entity for a session.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :param szEntityName: Full entity name to set limit for.
    :param nLimit: An integer denoting the maximum number of matches for this entity per document. Set to -1 for no limit. Set to 0 to skip matching for this entity.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: When set to a positive integer, eduction will stop at that number of matches for the entity. There is no limit on entity matches by default.
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer. See the EntityMatchLimitN configuration parameter.
    
    """


@_dll.export()
def EdkSessionSetMaxPrefilterBytesPerDoc(pSession: EdkSessionHandle, nMaxPrefilterBytesPerDoc: c_uint64) -> None:
    r"""  Sets the maximum number of prefilter output bytes without an Eduction match per document for a session.
     
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :param nMaxPrefilterBytes: The configured number of bytes of output from all prefilters, after which if no Eduction matches were generated, no further prefilter output is generated
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: When set to a positive integer, eduction will stop producing prefilter windows for a document once the byte length of all the prefilter windows generated so far exceeds this value. The default value is zero, meaning no limit.
    
    """


@_dll.export()
def EdkGetNextMatch(pSession: EdkSessionHandle) -> None:
    r"""  Advances the session to the next matched entity.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :raises: A standard :exc:`~edk.error.EdkException`. Set to :exc:`~edk.error.EdkNoMatchException` when no more matches can be found, or another :exc:`~edk.error.EdkException` if it fails.
    .. note:: This is the most basic function for getting matches. The session scans the input text it has received and returns when a match is found, or when no further matches exist.
             Call it multiple times to get all matching entities - the session keeps track of where to resume scanning. Any session that contains post-processing tasks will automatically 
             run those tasks on prospective matches before returning them.
    
    """


@_dll.export()
def EdkGetNextRepeatedMatch(pSession: EdkSessionHandle) -> None:
    r"""  Advances the session to the next match that has the same matched text as the current match.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :raises: A standard :exc:`~edk.error.EdkException`. Set to :exc:`~edk.error.EdkNoMatchException` when no more matches can be found, or another :exc:`~edk.error.EdkException` if it fails.
    .. note:: This function should be called after :any:`EdkGetNextMatch`. It can be used to iterate over the matches that have the same matched text as the match identified by :any:`EdkGetNextMatch`.
             Any such matches found will not be returned by subsequent calls to :any:`EdkGetNextMatch`.
    
    """


@_dll.export()
def EdkGetMatchEntityName(pSession: EdkSessionHandle) -> c_char_p:
    r"""  Gets the name of the currently matched entity.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :return: An entity name.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: Returns the name of the entity matched by the last :any:`EdkGetNextMatch`.
    .. seealso:: :any:`EdkGetNextMatch`
    
    """


@_dll.export()
def EdkGetMatchEntityField(pSession: EdkSessionHandle) -> c_char_p:
    r"""  Gets the name of the configured results field for the currently matched entity.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :return: An entity field name.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: Returns the name of the configured results field for the entity matched by the last :any:`EdkGetNextMatch`.
    .. seealso:: :any:`EdkGetNextMatch`
    
    """


@_dll.export()
def EdkGetMatchText(pSession: EdkSessionHandle) -> c_char_p:
    r"""  Returns the normalized text of the currently matched entity.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :return: The normalized text buffer.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: Returns the normalized text.
    .. seealso:: :any:`EdkGetNextMatch`
    
    """


@_dll.export()
def EdkGetMatchTextSize(pSession: EdkSessionHandle) -> c_size_t:
    r"""  Returns the size in bytes of the normalized text of the currently matched entity.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :return: A size_t variable which is set to the number of bytes for the normalized matching text. For matches containing multibyte characters, this will be greater than the number of characters.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. seealso:: :any:`EdkGetNextMatch`
    
    """


@_dll.export()
def EdkGetMatchTextLength(pSession: EdkSessionHandle) -> c_size_t:
    r"""  Returns the length in characters of the normalized text of the currently matched entity.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :return: A size_t variable which is set to the number of characters for the normalized matching text.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. seealso:: :any:`EdkGetNextMatch`
    
    """


@_dll.export()
def EdkGetMatchOrigText(pSession: EdkSessionHandle) -> c_char_p:
    r"""  Returns the text matched in the input text by the currently matched entity.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :return: The original text buffer.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: This returns the original input text before normalization.
    .. seealso:: :any:`EdkGetNextMatch`
    
    """


@_dll.export()
def EdkGetMatchOrigSize(pSession: EdkSessionHandle) -> c_size_t:
    r"""  Returns the size in bytes of the text matched in the input text by the currently matched entity.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :return: A size_t variable which is set to the number of bytes for the original matching text. For matches containing multibyte characters, this will be greater than the number of characters.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. seealso:: :any:`EdkGetNextMatch`
    
    """


@_dll.export()
def EdkGetMatchOrigLength(pSession: EdkSessionHandle) -> c_size_t:
    r"""  Returns the length in characters of the text matched in the input text by the currently matched entity.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :return: A size_t variable which is set to the number of characters for the original matching text.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. seealso:: :any:`EdkGetNextMatch`
    
    """


@_dll.export()
def EdkGetMatchOrigOffset(pSession: EdkSessionHandle) -> c_size_t:
    r"""  Returns the size in bytes of the offset of the matching text from the start of the input text, of the currently matched entity.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :return: A size_t variable which is set to the number of bytes by which the start of the match is offset from the start of the buffer. For matches containing multibyte characters, this will be greater than the number of characters.
     For buffers containing multi-byte characters, this will be greater than the number of characters.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. seealso:: :any:`EdkGetNextMatch`
    
    """


@_dll.export()
def EdkGetMatchOrigOffsetLength(pSession: EdkSessionHandle) -> c_size_t:
    r"""  Returns the size in characters of the offset of the matching text from the start of the input text, of the currently matched entity.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :return: A size_t variable which is set to the number of characters by which the match is offset from the start of the buffer.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. seealso:: :any:`EdkGetNextMatch`
    
    """


@_dll.export()
def EdkGetMatchScore(pSession: EdkSessionHandle) -> c_double:
    r"""  Returns the matching score of the currently matched entity.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :return: A double-precision floating point number that receives the score.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. seealso:: :any:`EdkGetNextMatch`
    
    """


@_dll.export()
def EdkGetRepeatedMatchByteOffset(pSession: EdkSessionHandle) -> c_size_t:
    r"""  Returns the size in bytes of the offset of the matching text from the start of the input text, of the current repeated match.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :return: A size_t variable which is set to the number of bytes by which the match is offset from the start of the buffer.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. seealso:: :any:`EdkGetNextRepeatedMatch`
    
    """


@_dll.export()
def EdkGetRepeatedMatchCodepointOffset(pSession: EdkSessionHandle) -> c_size_t:
    r"""  Returns the size in codepoints of the offset of the matching text from the start of the input text, of the current repeated match.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :return: A size_t variable which is set to the number of codepoints by which the match is offset from the start of the buffer.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. seealso:: :any:`EdkGetNextRepeatedMatch`
    
    """


@_dll.export()
def EdkGetMatchTablePosition(pSession: EdkSessionHandle) -> tuple[c_int,c_int]:
    r"""  When header/cell entities are configured, returns the source row/column of the currently matched entity.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :return: A tuple containing:
        An integer that receives the table row of the cell containing the current entity match, or -1 if the match was not from a structured table.
        An integer that receives the table column of the cell containing the current entity match, or -1 if the match was not from a structured table.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. seealso:: :any:`EdkGetNextMatch`
    
    """


@_dll.export()
def EdkGetMatchTableNumber(pSession: EdkSessionHandle) -> c_int:
    r"""  When header/cell entities are configured, returns the source table number of the currently matched entity.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :return: An integer that receives the table number of the cell containing the current entity match.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. seealso:: :any:`EdkGetNextMatch`
    
    """


@_dll.export()
def EdkGetMatchComponentCount(pSession: EdkSessionHandle) -> c_size_t:
    r"""  Returns the number of components in the currently matched entity.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :return: An integer that receives the number of components in an entity.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: Components must be enabled (via EdkSetEnableComponents or a config file with EnableComponents=TRUE) for this to return a nonzero value, even if the grammar(s) used support components.
    .. seealso:: :any:`EdkGetNextMatch`
    
    """


@_dll.export()
def EdkGetMatchComponentName(pSession: EdkSessionHandle, nIndex: c_size_t) -> c_char_p:
    r"""  Returns the name of the Nth component of the currently matched entity.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :param nIndex:  The index of the component.
    :return: The component name handle.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. seealso:: :any:`EdkGetNextMatch`
    
    """


@_dll.export()
def EdkGetMatchComponentText(pSession: EdkSessionHandle, nIndex: c_size_t) -> c_char_p:
    r"""  Returns the text of the Nth component of the currently matched entity.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :param nIndex:  The index of the component.
    :return: The component text variable.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. seealso:: :any:`EdkGetNextMatch`
    
    """


@_dll.export()
def EdkGetMatchComponentSize(pSession: EdkSessionHandle, nIndex: c_size_t) -> c_size_t:
    r"""  Returns the size (in bytes) of the Nth component of the currently matched entity.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :param nIndex:  The index of the component.
    :return: A size variable.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. seealso:: :any:`EdkGetNextMatch`
    
    """


@_dll.export()
def EdkGetMatchComponentLength(pSession: EdkSessionHandle, nIndex: c_size_t) -> c_size_t:
    r"""  Returns the length (in characters) of the Nth component of the currently matched entity.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :param nIndex:  The index of the component.
    :return: A length variable.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. seealso:: :any:`EdkGetNextMatch`
    
    """


@_dll.export()
def EdkGetMatchComponentOffset(pSession: EdkSessionHandle, nIndex: c_size_t) -> c_size_t:
    r"""  Returns the offset (from the beginning of the current normalized text, in bytes) of the Nth component of the currently matched entity.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :param nIndex:  The index of the component.
    :return: A size_t variable which is set to the number of bytes by which the match is offset from the start of the normalized text.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. seealso:: :any:`EdkGetNextMatch`
    
    """


@_dll.export()
def EdkGetMatchComponentOffsetLength(pSession: EdkSessionHandle, nIndex: c_size_t) -> c_size_t:
    r"""  Returns the offset (from the beginning of the current normalized text, in characters) of the Nth component of the currently matched entity.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :param nIndex:  The index of the component.
    :return: A size_t variable which is set to the number of characters by which the match is offset from the start of the normalized text.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. seealso:: :any:`EdkGetNextMatch`
    
    """


@_dll.export()
def EdkGetMatchTimedOut(pSession: EdkSessionHandle) -> EdkBool:
    r"""  Returns whether the last match timed out before returning.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :return: A boolean variable. If the last match timed out, this will be set to true.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. seealso:: :any:`EdkGetNextMatch`
    
    """


@_dll.export(errhandler=True)
def EdkGetLastSessionError(pSession: EdkSessionHandle) -> tuple[EdkError,c_char_p]:
    r"""  Returns the latest error code from this session.
    
    :param pSession: An :any:`EdkSessionHandle` previously allocated by a call to :any:`EdkSessionCreate`.
    :return: A tuple containing:
        A standard :any:`EdkError` value corresponding to the last error of the session.
        A string buffer to hold the error message.
    
    """


def EdkSetInputCallback(session: EdkSessionHandle, callback: Callable[[bytearray], int]) -> None:
    r""" Sets a callback to provide character data for a session.
    
    :param session: An :class:`EdkSessionHandle` previously allocated by a call to :func:`EdkSessionCreate`.
    :param callback: Callable python object that will be called with a writable bytes-like object.
                    It should read bytes into the buffer and return the number of bytes read.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: Input data must be encoded in UTF-8.
             Once a callback has been set, it cannot be changed, nor can :func:`EdkAddInputText` be called.
    """
    if not callable(callback):
        raise TypeError("EdkSetInputCallback requires a callable object")
    return EdkSetInputStream(session, py_object(callback), _stream._invoke_callback)

