###
# Copyright 2023 Open Text.
# 
# The only warranties for products and services of Open Text and its
# affiliates and licensors ("Open Text") are as may be set forth in the
# express warranty statements accompanying such products and services.
# Nothing herein should be construed as constituting an additional warranty.
# Open Text shall not be liable for technical or editorial errors or omissions
# contained herein. The information contained herein is subject to change
# without notice.
# 
# Except as specifically indicated otherwise, this document contains
# confidential information and a valid license is required for possession, use
# or copying. If this work is provided to the U.S. Government, consistent with
# FAR 12.211 and 12.212, Commercial Computer Software, Computer Software
# Documentation, and Technical Data for Commercial Items are licensed to the
# U.S. Government under vendor's standard commercial license.
###
__all__ = ['EdkHandleBase']


import configparser
import io
import os

from collections.abc import Callable
from typing import Any, Optional

from .. import error
from ..typehints import ByteLike


class EdkHandleBase:
    """
    Base for classes wrapping handles allocated by edk.api calls, for use as a context manager.
    """
    __slots__ = ('__handle', '_constructresult')
    _handletype:type
    _destructor:Callable[['EdkHandleBase'],None]

    def __init__(self, constructor:Optional[Callable[...,None]]=None, *args:Any) -> None:
        """
        Create a new instance, using edk.api function `constructor` to create a handle.
        Trailing arguments are forwarded to the constructor function; the handle itself
        is by default passed as the final argument. An Ellipsis `...` may be used as a
        placeholder parameter to override this behavior.
        """
        self.__handle = self._handletype()
        if constructor:
            try:
                i = args.index(Ellipsis)
            except ValueError:
                i = len(args)
            self._constructresult = constructor(*(args[:i]), *self._handle_refs, *(args[i+1:]))

    def __del__(self):
        self.destruct()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.destruct()

    def __bool__(self):
        return bool(self.__handle)

    def destruct(self) -> None:
        """
        Explicitly invoke the registered destructor function.
        This is called automatically by __exit__ (and __del__);
        it is recommended use an instance in a with...as block,
        ensuring resources are freed when leaving the context.
        """
        if not self: return #no-op
        try:
            self._destructor(self)
        except error.EdkException:
            pass
        self.__handle = self._handletype()

    @property
    def _handle(self):
        return self.__handle

    @property
    def _handle_refs(self):
        return (self.__handle,)

    @property
    def _value(self):
        return self.__handle.value if self else None

    @property
    def _as_parameter_(self):
        return self.__handle

    @staticmethod
    def _is_bytes(arg:Any) -> bool:
        """ Can this argument be passed as a C string, or must it be encoded first? """
        return isinstance(arg, (bytes, bytearray))

    @staticmethod
    def _to_bytes(arg:Any, encoding:str='utf-8') -> ByteLike:
        """ Coerce argument to a C string-compatible type, if possible """
        if isinstance(arg, os.PathLike):
            arg = str(arg)
        elif isinstance(arg, configparser.ConfigParser):
            stream = io.StringIO()
            arg.write(stream)
            stream.seek(0)
            arg = stream.read()
        if not EdkHandleBase._is_bytes(arg):
            arg = arg.encode(encoding)
        return arg
