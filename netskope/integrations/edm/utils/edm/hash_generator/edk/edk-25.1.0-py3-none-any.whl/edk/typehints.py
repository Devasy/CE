###
# Copyright 2024 Open Text.
# 
# The only warranties for products and services of Open Text and its
# affiliates and licensors ("Open Text") are as may be set forth in the
# express warranty statements accompanying such products and services.
# Nothing herein should be construed as constituting an additional warranty.
# Open Text shall not be liable for technical or editorial errors or omissions
# contained herein. The information contained herein is subject to change
# without notice.
# 
# Except as specifically indicated otherwise, this document contains
# confidential information and a valid license is required for possession, use
# or copying. If this work is provided to the U.S. Government, consistent with
# FAR 12.211 and 12.212, Commercial Computer Software, Computer Software
# Documentation, and Technical Data for Commercial Items are licensed to the
# U.S. Government under vendor's standard commercial license.
###
import configparser
import datetime
import numbers

from collections.abc import Callable, Sequence
from os import PathLike
from typing import Any, NamedTuple, Optional, Protocol, TypeVar


S = TypeVar('S', str, bytes)


ByteLike = bytes|bytearray

StringLike = str|ByteLike

Configuration = configparser.ConfigParser|StringLike

PathToFile = PathLike|StringLike

PointInTime = datetime.datetime|numbers.Number

InputCallback = Callable[[bytearray], int]

LogCallback = Callable[[int, ByteLike], None]


class Loggable(Protocol):
    """Object that provides a `.log()` callback, such as a logging.Logger"""
    log:Callable[...,None]


class TablePosition(NamedTuple):
    """Gives the cell position for matches found inside a structured table"""
    row: int
    "The row offset of the matching cell; the header row is row zero"
    col: int
    "The column offset of the matching cell"


class ComponentLike(Protocol[S]):
    """Represents a match Component (named capture)"""
    name: S
    "The name of the component"
    text: S
    "The captured component text"
    offset: int
    "The offset of the component within the (normalized) entity text"
    def asdict(self) -> dict[str,Any]:
        """A dictionary representing the component"""


class MatchLike(Protocol[S]):
    """
    Represents the current match from an Eduction Session.
    
    Text attributes will be either `str` or `bytes` objects,
    reflecting the type of the input data provided to the
    Eduction session.

    Similarly, offset values will be in terms of Unicode
    characters when in "string mode", or bytes counts when
    working with raw byte input.
    """
    name: S
    "The matched entity name"
    text: S
    "The normalized match text"
    orig: S
    "The text originally matched in the input"
    score: float
    "The score given to the match"
    offset: int
    "The match's position in the input text"
    tablepos: Optional[TablePosition]
    "The row+column number of the match, if in table mode"
    tablenum: Optional[int]
    "The sequential table number, if in table mode"
    components: Sequence[ComponentLike[S]]
    "The captured components of the match"

    def asdict(self, full:bool=False) -> dict[str,Any]:
        """A dictionary representing the match"""

    def persist(self) -> 'MatchLike[S]':
        """A copy of the match which will retain data when the originating session is advanced"""
