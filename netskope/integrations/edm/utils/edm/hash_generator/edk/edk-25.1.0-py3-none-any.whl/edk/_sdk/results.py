###
# Copyright 2023 Open Text.
# 
# The only warranties for products and services of Open Text and its
# affiliates and licensors ("Open Text") are as may be set forth in the
# express warranty statements accompanying such products and services.
# Nothing herein should be construed as constituting an additional warranty.
# Open Text shall not be liable for technical or editorial errors or omissions
# contained herein. The information contained herein is subject to change
# without notice.
# 
# Except as specifically indicated otherwise, this document contains
# confidential information and a valid license is required for possession, use
# or copying. If this work is provided to the U.S. Government, consistent with
# FAR 12.211 and 12.212, Commercial Computer Software, Computer Software
# Documentation, and Technical Data for Commercial Items are licensed to the
# U.S. Government under vendor's standard commercial license.
###
__all__ = ['EdkBuffer', 'EdkStringArray', 'EdkMatchCounts']


import ctypes

from .. import api
from .base import EdkHandleBase


class EdkBuffer(EdkHandleBase):
    """
    Manages a string or memory buffer returned by the EDK API.
    """
    _handletype = ctypes.c_char_p
    _destructor = staticmethod(api.generic.EdkFreeBuffer)
    __slots__ = ()

    @property
    def value(self):
        return self._value


class _EdkArrayBase(EdkHandleBase):
    _sizetype = ctypes.c_int
    __slots__ = ()

    @staticmethod
    def _destructor(inst):
        size = inst._sizetype(inst._constructresult)
        inst._free_array(*inst._handle_refs, ctypes.byref(size))
        inst._constructresult = size.value

    def __len__(self):
        return self._constructresult if self else 0

    def __getitem__(self, key):
        if not isinstance(key, int):
            raise TypeError("{cls} index should be an integer (got: {idx})".format(
                cls=self.__class__.__name__,idx=key))
        num = len(self)
        if key < 0:
            key = num + key
        if key < 0 or key >= num:
            raise IndexError("{cls} index out of range".format(cls=self.__class__.__name__))
        return self._get_index(key)

    def __iter__(self):
        for index in range(len(self)):
            yield self._get_index(index)

    def _get_index(self, index):
        return self._handle[index]


class EdkStringArray(_EdkArrayBase):
    """
    Manages a string array returned by the EDK API.
    """
    _handletype = ctypes.POINTER(ctypes.c_char_p)
    _free_array = staticmethod(api.generic.EdkFreeStringArray)
    __slots__ = ()


class EdkMatchCounts(_EdkArrayBase):
    """
    Manages parallel arrays of names and counts returned by the EDK API.
    """
    class _handletype(ctypes.Structure):
        _fields_ = [
            ('names', ctypes.POINTER(ctypes.c_char_p)),
            ('counts', ctypes.POINTER(ctypes.c_size_t))
        ]
    _free_array = staticmethod(api.generic.EdkDestroyMatchCounts)
    __slots__ = ()

    def _for_handle_fields(self, fn):
        return tuple(fn(getattr(self._handle, f[0])) for f in self._handletype._fields_)

    @property
    def _handle_refs(self):
        return self._for_handle_fields(ctypes.byref)

    def _get_index(self, index):
        return self._for_handle_fields(lambda f:f[index])
