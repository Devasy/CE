###
# Copyright 2023 Open Text.
# 
# The only warranties for products and services of Open Text and its
# affiliates and licensors ("Open Text") are as may be set forth in the
# express warranty statements accompanying such products and services.
# Nothing herein should be construed as constituting an additional warranty.
# Open Text shall not be liable for technical or editorial errors or omissions
# contained herein. The information contained herein is subject to change
# without notice.
# 
# Except as specifically indicated otherwise, this document contains
# confidential information and a valid license is required for possession, use
# or copying. If this work is provided to the U.S. Government, consistent with
# FAR 12.211 and 12.212, Commercial Computer Software, Computer Software
# Documentation, and Technical Data for Commercial Items are licensed to the
# U.S. Government under vendor's standard commercial license.
###
import io
from typing import Optional
from ..typehints import ByteLike, Loggable


class BytesInputCallback:
    """ Wrap a byte stream for use with SetInputStream """
    __slots__ = ('_stream',)

    def __init__(self, stream:io.BufferedIOBase):
        if not isinstance(stream, io.BufferedIOBase):
            raise TypeError("Not a binary stream")
        self._stream = stream

    def __call__(self, buffer:bytearray) -> int:
        return self._stream.readinto(buffer)


class TextInputCallback:
    """ Wrap a text stream for use with SetInputStream """
    __slots__ = ('_readbuf', '_readlen', '_stream')

    def __init__(self, stream:io.TextIOBase, readlen:int=4096):
        if not isinstance(stream, io.TextIOBase):
            raise TypeError("Not a text stream")
        self._stream = stream
        self._readlen = readlen
        self._readbuf:Optional[bytearray] = None

    def __call__(self, buffer:bytearray) -> int:
        bytes_copied = 0
        buffer_space = len(buffer)
        while buffer_space > 0:
            if not self._readbuf:
                self._readbuf = bytearray(self._stream.read(self._readlen), encoding='utf-8')
                if not self._readbuf:
                    break
            bytes_to_copy = min(buffer_space, len(self._readbuf))
            new_bytes_copied = bytes_copied + bytes_to_copy
            buffer[bytes_copied:new_bytes_copied] = self._readbuf[:bytes_to_copy]
            del self._readbuf[:bytes_to_copy]
            buffer_space -= bytes_to_copy
            bytes_copied = new_bytes_copied
        return bytes_copied


class LoggingCallback:
    """ Wrapper a logger instance for use as an EDK logging callback """
    __slots__ = ('_logger',)

    def __init__(self, logger:Loggable):
        if not callable(getattr(logger, 'log', None)):
            raise TypeError("Not a logger instance")
        self._logger = logger

    def __call__(self, level:int, msg:ByteLike) -> None:
        level = min((level + 10)//2, 50)
        self._logger.log(level, msg.decode('utf-8').rstrip('\r\n'))
