###
# Copyright 2023 Open Text.
# 
# The only warranties for products and services of Open Text and its
# affiliates and licensors ("Open Text") are as may be set forth in the
# express warranty statements accompanying such products and services.
# Nothing herein should be construed as constituting an additional warranty.
# Open Text shall not be liable for technical or editorial errors or omissions
# contained herein. The information contained herein is subject to change
# without notice.
# 
# Except as specifically indicated otherwise, this document contains
# confidential information and a valid license is required for possession, use
# or copying. If this work is provided to the U.S. Government, consistent with
# FAR 12.211 and 12.212, Commercial Computer Software, Computer Software
# Documentation, and Technical Data for Commercial Items are licensed to the
# U.S. Government under vendor's standard commercial license.
###
import contextlib
import json

from ._base import EdkToolModuleWithConfig, EdkToolModuleWithInput

class Extract(EdkToolModuleWithConfig, EdkToolModuleWithInput):

    command = 'extract'
    aliases = ['e']
    help = 'Search for Eduction matches in text'

    def run(self):
        with contextlib.ExitStack() as ctx:
            factory = ctx.enter_context(self.get_factory())
            engine = ctx.enter_context(self.get_engine(factory))
            session = ctx.enter_context(engine.session())
            if self.inputfile:
                input = ctx.enter_context(open(self.inputfile, 'r', encoding='utf-8'))
                session.input_stream = input
            else: #if self.inputtext
                session.add_input_text(self.inputtext, final=True)
            indent = 4 * ' ';
            print('{\n', indent, '"matches": [', sep='', end='')
            count = 0
            for match in session:
                print(',' if count > 0 else '',
                      '\n', 2 * indent,
                      json.dumps(match.asdict(full=True)), sep='', end='')
                count += 1
            if count > 0:
                print('\n', indent, sep='', end='')
            print('],\n', indent, '"count": ', count, '\n}', sep='')


if __name__ == '__main__':
    Extract.main()
