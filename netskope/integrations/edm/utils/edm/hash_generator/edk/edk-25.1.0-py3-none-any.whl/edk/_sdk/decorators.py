###
# Copyright 2023 Open Text.
# 
# The only warranties for products and services of Open Text and its
# affiliates and licensors ("Open Text") are as may be set forth in the
# express warranty statements accompanying such products and services.
# Nothing herein should be construed as constituting an additional warranty.
# Open Text shall not be liable for technical or editorial errors or omissions
# contained herein. The information contained herein is subject to change
# without notice.
# 
# Except as specifically indicated otherwise, this document contains
# confidential information and a valid license is required for possession, use
# or copying. If this work is provided to the U.S. Government, consistent with
# FAR 12.211 and 12.212, Commercial Computer Software, Computer Software
# Documentation, and Technical Data for Commercial Items are licensed to the
# U.S. Government under vendor's standard commercial license.
###
import inspect
import functools
import numbers
import re

from collections.abc import Callable
from types import ModuleType
from typing import Any, Optional

from ..api import _ctypesmapping


def _to_snake_case(name:str) -> str:
    """ Transform CamelCased name to a Pythonic snake_case one """
    for p in [r'([^_])([A-Z][a-z])', r'([a-z0-9])([A-Z])']:
        name = re.sub(p, r'\1_\2', name)
    return name.lower()


class _AutoAttrsBase:
    """
    Base for class decorator that automatically creates attributes (properties, methods)
    from functions available in the namespace in a given module, matching a given regex.
    """
    def __init__(self,
                 module:ModuleType,
                 pattern:str,
                 transform:Callable[[re.Match[str]],str]=lambda m:m[0],
                 snakify:bool=True):
        attrs = {}
        for name,apicall in inspect.getmembers(module, callable):
            m = re.fullmatch(pattern, name)
            if not m: continue
            name = transform(m)
            if snakify:
                name = _to_snake_case(name)
            assert name not in attrs, f"Duplicate match '{name}' for auto-attribute pattern '{pattern}'"
            attrs[name] = self._create_attr(name, apicall)
        self._attrs = attrs

    def __call__(self, cls:type) -> type:
        for name,attr in self._attrs.items():
            if hasattr(cls, name): continue
            setattr(cls, name, attr)
        return cls

    @staticmethod
    def _getdocfirstline(obj:Any) -> Optional[str]:
        doc:Optional[str]=getattr(obj,'__doc__',None)
        if doc: doc = doc.strip().partition('\n')[0]
        return doc


class AutoMethods(_AutoAttrsBase):
    """ Creates methods from edk.api functions, forwarding parameters """
    def _create_attr(self, name:str, apicall:Callable[...,Any]) -> Callable[...,Any]:
        def method(that, *args, **kwargs): # No annotation
            # functools.partialmethod can't have __docs__
            return apicall(that, *args, **kwargs)
        method.__doc__ = self._getdocfirstline(apicall)
        method.__name__ = method.__qualname__ = name
        apisig = inspect.signature(apicall)
        method.__signature__ = apisig.replace(parameters=[
            p.replace(annotation=_ctypesmapping.map_param_type(p.annotation)
                        if n else inspect.Parameter.empty,
                      name=p.name if n else 'self')
                for n,p in enumerate(apisig.parameters.values())])
        return method


class AutoGetProps(_AutoAttrsBase):
    """ Create gettable properties; calls the associated edk.api function and returns the result """
    def _create_attr(self, _:str, apicall:Callable[...,Any]) -> property:
        return property(fget=apicall, doc=self._getdocfirstline(apicall))


class AutoSetProps(_AutoAttrsBase):
    """ Creates settable properties; setting invokes the associated edk.api function """
    def _create_attr(self, name:str, apicall:Callable[...,None]) -> property:
        def raise_getter(self): # No annotation
            raise AttributeError(f"The `{name}` attribute cannot be read, only assigned.")
        _,param = inspect.signature(apicall).parameters.values()
        rt = _ctypesmapping.map_param_type(param.annotation)
        raise_getter.__signature__ = inspect.Signature(return_annotation=rt)
        return property(fget=raise_getter, fset=apicall,
                        doc=self._getdocfirstline(apicall) + "\nThis attribute cannot be read, only assigned.")


class AutoSetMillisecondProps(AutoSetProps):
    """ Creates settable properties mapping seconds to milliseconds; setting invokes the associated edk.api function """
    def _create_attr(self, name:str, apicall:Callable[...,None]) -> property:
        @functools.wraps(apicall)
        def setter(that, value): # No annotation
            return apicall(that, value*1000 if isinstance(value, numbers.Number) else value)
        return super()._create_attr(name, setter)
