###
# Copyright 2024 Open Text.
# 
# The only warranties for products and services of Open Text and its
# affiliates and licensors ("Open Text") are as may be set forth in the
# express warranty statements accompanying such products and services.
# Nothing herein should be construed as constituting an additional warranty.
# Open Text shall not be liable for technical or editorial errors or omissions
# contained herein. The information contained herein is subject to change
# without notice.
# 
# Except as specifically indicated otherwise, this document contains
# confidential information and a valid license is required for possession, use
# or copying. If this work is provided to the U.S. Government, consistent with
# FAR 12.211 and 12.212, Commercial Computer Software, Computer Software
# Documentation, and Technical Data for Commercial Items are licensed to the
# U.S. Government under vendor's standard commercial license.
###
import enum

class EdkErrorCode(enum.IntEnum):
    """
    Enumeration of numeric error codes (`EdkError` values) returned from EDK library calls
    """
    original:str    # Corresponding error code name defined in the C API
    comment:str     # Comment describing the error code in edk.h header

    def __new__(cls, code:int, orig:str, comment:str) -> 'EdkErrorCode':
        obj = int.__new__(cls)
        obj._value_ = code
        obj.original = orig
        obj.comment = comment
        return obj

    def __str__(self) -> str:
        return f"{self.value} ({self.original}: {self.comment.rstrip('.')})"

    @property
    def is_success(self) -> bool:
        """Did the operation succeed?"""
        return self.value == 0

    EDKSUCCESS = (0, "EdkSuccess",
        "Success. Numerically equivalent to 0.")
    EDKERRORBASE = (200, "EdkErrorBase",
        "Used as a base value for all Eduction SDK error codes other than ::EdkSuccess.")
    EDKFAIL = (201, "EdkFail",
        "Unspecified failure.")
    EDKNOMATCH = (202, "EdkNoMatch",
        "No more matches found.")
    EDKERREXCEPTION = (203, "EdkErrException",
        "An exception was raised.")
    EDKERRNEEDMOREDATA = (204, "EdkErrNeedMoreData",
        "Not used.")
    EDKERROPENFILE = (205, "EdkErrOpenFile",
        "An attempt to open a file failed.")
    EDKERRREADFILE = (206, "EdkErrReadFile",
        "An attempt to read from a file failed.")
    EDKERRWRITEFILE = (207, "EdkErrWriteFile",
        "An attempt to write to a file failed.")
    EDKERRSYNTAX_EXPECTED = (208, "EdkErrSyntax_Expected",
        "A syntax error was found.")
    EDKERRSYNTAX_UNEXPECTED = (209, "EdkErrSyntax_UnExpected",
        "A syntax error was found.")
    EDKERRSYNTAX_UNEXPECTED_END_OF_PATTERN = (210, "EdkErrSyntax_UnExpected_End_Of_Pattern",
        "A syntax error was found. The end of a pattern was expected.")
    EDKERRSYNTAX_UNKNOWN_ENTITY = (211, "EdkErrSyntax_Unknown_Entity",
        "A syntax error was found. The entity name is unknown.")
    EDKERRENTITYNOTFOUND = (212, "EdkErrEntityNotFound",
        "Entity not found.")
    EDKERRDUPLICATEARCHIVEENTRY = (213, "EdkErrDuplicateArchiveEntry",
        "A duplicate archive entry exists.")
    EDKERRINVALIDARG = (214, "EdkErrInvalidArg",
        "An invalid argument was found.")
    EDKERRENTITYALREADYDEFINED = (215, "EdkErrEntityAlreadyDefined",
        "An entity is already defined.")
    EDKERRNOARCHIVEENTRYFOUND = (216, "EdkErrNoArchiveEntryFound",
        "No archive entry was found.")
    EDKERRBADRESOURCEFILE = (217, "EdkErrBadResourceFile",
        "Bad resource file.")
    EDKERRCORRUPTEDRESOURCEFILE = (218, "EdkErrCorruptedResourceFile",
        "Corrupted resource file.")
    EDKERRXMLINITIALIZATIONFAILURE = (219, "EdkErrXMLInitializationFailure",
        "XML initialization failure.")
    EDKERRXMLPARSINGERROR = (220, "EdkErrXMLParsingError",
        "XML parsing error.")
    EDKERRINVALIDXMLDATA = (221, "EdkErrInvalidXmlData",
        "An error was found in the XML data.")
    EDKERROUTOFMEMORY = (222, "EdkErrOutOfMemory",
        "Out of memory.")
    EDKERRSYNTAX_BADIDENTIFIER = (223, "EdkErrSyntax_BadIdentifier",
        "Bad identifier in a column.")
    EDKERRENGINELOCKED = (224, "EdkErrEngineLocked",
        "An attempt was made to call a function after a session is created that is only allowed to be called before the session is created.")
    EDKERRENTITYNOTPUBLIC = (225, "EdkErrEntityNotPublic",
        "An entity that is not public is being referred to.")
    EDKERRNOPUBLICENTITYDEFINED = (226, "EdkErrNoPublicEntityDefined",
        "No public entity is defined.")
    EDKERRCONFIGERROR = (227, "EdkErrConfigError",
        "Configuration error.")
    EDKERRLICENSEEXPIRED = (228, "EdkErrLicenseExpired",
        "The licence key provided has expired.")
    EDKERRLICENSENOTSET = (229, "EdkErrLicenseNotSet",
        "The licence key has not been found/set.")
    EDKERRLICENSEINVALID = (230, "EdkErrLicenseInvalid",
        "The licence key provided is not valid for Eduction.")
    EDKERRCONCEPTTOKENIZERINITFAILED = (231, "EdkErrConceptTokenizerInitFailed",
        "The concept tokenizer initialization failed.")
    EDKERRINPUTSTREAMSET = (232, "EdkErrInputStreamSet",
        "An input stream has been set. Text may not be added.")
    EDKERRJNIEXCEPTIONTHROWN = (233, "EdkErrJNIExceptionThrown",
        "An exception was thrown in the Eduction Java Native Interface (JNI) layer.")
    EDKERRJAVALICENSEKEYNOTSET = (234, "EdkErrJavaLicenseKeyNotSet",
        "An attempt to call an EDKEngine's method has been made either without setting the license key or after the destroy method has been called.")
    EDKSESSIONDESTROYED = (235, "EdkSessionDestroyed",
        "An attempt to call an EDKSessions's method has been made after the destroy method has been called.")
    EDKCHECKSUMERROR = (236, "EdkChecksumError",
        "A checksum in the file has an incorrect value")
    EDKERRINVALIDUTF8 = (237, "EdkErrInvalidUTF8",
        "The input is not valid UTF8")
    EDKDISALLOWEDVERSIONNUMBER = (238, "EdkDisallowedVersionNumber",
        "The XML file contains an invalid version tag")
    EDKERRINPUTDIRNOTSET = (239, "EdkErrInputDirNotSet",
        "The input directory or file is not set")
    EDKERRCFGGMRNOTSET = (240, "EdkErrCfgGmrNotSet",
        "The grammar/config file is not set.")
    EDKERRBADPOSTPROCESSSCRIPT = (241, "EdkErrBadPostProcessScript",
        "The post-process script is nonexistent or invalid.")
    EDKERRTABLEMODENOTCONFIGURED = (242, "EdkErrTableModeNotConfigured",
        "An operation was attempted that is only available when table extraction is configured")
    EDKERRNOTSUPPORTED = (243, "EdkErrNotSupported",
        "This operation is not supported.")
    EDKERRVERSIONNOTLICENSED = (244, "EdkErrVersionNotLicensed",
        "The licence key provided does not cover this version/build.")
    EDKERRINTERNALSTATE = (245, "EdkErrInternalState",
        "Bad internal state")
    EDKERRLICENSETRUNCATED = (246, "EdkErrLicenseTruncated",
        "The license key provided is truncated.")
