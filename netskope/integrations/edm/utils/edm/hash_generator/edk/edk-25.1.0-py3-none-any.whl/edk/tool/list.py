###
# Copyright 2023 Open Text.
# 
# The only warranties for products and services of Open Text and its
# affiliates and licensors ("Open Text") are as may be set forth in the
# express warranty statements accompanying such products and services.
# Nothing herein should be construed as constituting an additional warranty.
# Open Text shall not be liable for technical or editorial errors or omissions
# contained herein. The information contained herein is subject to change
# without notice.
# 
# Except as specifically indicated otherwise, this document contains
# confidential information and a valid license is required for possession, use
# or copying. If this work is provided to the U.S. Government, consistent with
# FAR 12.211 and 12.212, Commercial Computer Software, Computer Software
# Documentation, and Technical Data for Commercial Items are licensed to the
# U.S. Government under vendor's standard commercial license.
###
import contextlib
import json
import sys

from ._base import EdkToolModuleBase

class List(EdkToolModuleBase):

    command = 'list'
    aliases = ['l']
    help = 'List the public entities in an Eduction grammar'

    @classmethod
    def add_arguments(cls, parser):
        super().add_arguments(parser)
        parser.add_argument('-g', '--grammarfile', required=True, help='Grammar file path')

    def __init__(self, args) -> None:
        super().__init__(args)
        self.grammarfile = args.grammarfile

    def run(self):
        with contextlib.ExitStack() as ctx:
            factory = ctx.enter_context(self.get_factory())
            engine = ctx.enter_context(factory.engine())
            engine.load(grammarpath=self.grammarfile)
            json.dump({
                'grammar': self.grammarfile,
                'entities': list(engine.entities)
            }, fp=sys.stdout, indent=4)


if __name__ == '__main__':
    List.main()
