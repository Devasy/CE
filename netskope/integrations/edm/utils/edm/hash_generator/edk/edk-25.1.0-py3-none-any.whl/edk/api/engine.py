###
# Copyright 2024 Open Text.
# 
# The only warranties for products and services of Open Text and its
# affiliates and licensors ("Open Text") are as may be set forth in the
# express warranty statements accompanying such products and services.
# Nothing herein should be construed as constituting an additional warranty.
# Open Text shall not be liable for technical or editorial errors or omissions
# contained herein. The information contained herein is subject to change
# without notice.
# 
# Except as specifically indicated otherwise, this document contains
# confidential information and a valid license is required for possession, use
# or copying. If this work is provided to the U.S. Government, consistent with
# FAR 12.211 and 12.212, Commercial Computer Software, Computer Software
# Documentation, and Technical Data for Commercial Items are licensed to the
# U.S. Government under vendor's standard commercial license.
###
from .types import *
from ._dll import edkdll as _dll
from .annotations import EdkTimeInterval
from . import _logging, session

from ctypes import POINTER, c_char_p, c_double, c_int, c_size_t, c_void_p, py_object
from collections.abc import Callable


class EdkEngineHandle(c_void_p):
    """
    A handle to an EDK Engine.
    """


@_dll.export()
def EdkEngineDestroy(pEngine: EdkEngineHandle) -> None:
    r"""  Destroys an EDK engine.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a successful call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: Frees any allocated memory owned by the EDK engine, and releases any resources it had opened. 
     Before calling :any:`EdkEngineDestroy`, ensure that all associated sessions with the engine are destroyed.
    .. seealso:: :any:`EdkFactoryMakeEngine` :any:`EdkFactoryMakeEngineFromConfigFile` :any:`EdkFactoryMakeEngine` :any:`EdkFactoryMakeEngineFromConfigFile` :any:`EdkFactoryMakeEngineFromConfigBuffer` :any:`EdkSessionDestroy`
    
    """


@_dll.export()
def EdkSetEnableComponents(pEngine: EdkEngineHandle, bEnable: EdkBool) -> None:
    r"""  Selects entity component matching capabilities.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param bEnable: A Boolean, that if true, enables component matching. If set to false, it is disabled. The default is false.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: In a grammar, you can define sections of an entity pattern as components. Component matching extracts and returns these pattern sections, in addition to the usual match info.
    .. seealso:: :any:`EdkGetMatchComponentCount` :any:`EdkGetMatchComponentName`
    
    """


@_dll.export()
def EdkSetEnableUniqueMatches(pEngine: EdkEngineHandle, bEnable: EdkBool) -> None:
    r"""  Selects entity unique matching capabilities.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param bEnable: A Boolean, that if true, restricts matches to unique values. If set to false, all match value instances are returned. The default is false.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: If this is enabled, only one value of all identical match values is returned.
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer.
    
    """


@_dll.export()
def EdkSetCaseSensitiveFieldName(pEngine: EdkEngineHandle, bEnable: EdkBool) -> None:
    r"""  Sets case sensitive field names.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param bEnable: A Boolean, that if true, field names are case sensitive. The default is false.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: If this is enabled, output field names retain their name exactly as configured.
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer.
    
    """


@_dll.export()
def EdkSetMatchTimeout(pEngine: EdkEngineHandle, nMatchTimeout: EdkTimeInterval[c_size_t]) -> None:
    r"""  Sets the time in seconds when a match should time out.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param nMatchTimeout: An integer denoting the time in seconds when a match should time out. Defaults to 60.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: If Eduction takes more than this number of seconds to find the next match, a timeout occurs.
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer.
    
    """


@_dll.export()
def EdkSetRequestTimeout(pEngine: EdkEngineHandle, nRequestTimeout: EdkTimeInterval[c_size_t]) -> None:
    r"""  Sets the time in seconds when a 'request' to retrieve matches should time out.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param nRequestTimeout: An integer denoting the time in seconds when a 'request' to retrieve matches should time out. Defaults to 300.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: If Eduction takes more than this number of seconds to find all matches, a timeout occurs.
    .. seealso:: :any:`EdkSessionSetStartTime`
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer.
    
    """


@_dll.export()
def EdkSetMaxMatchLength(pEngine: EdkEngineHandle, nMaxMatchLength: c_size_t) -> None:
    r"""  Sets the length of the longest text match for the engine.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param nMaxMatchLength: An integer denoting the maximum number of bytes allowed for a match extracted by the engine.
     When matching ASCII characters, e.g. A-Z, a-z, 0-9, the parameter will allow the same number of characters matched. For non-ASCII characters
     (e.g. accented characters, non-English characrers), the maximum number of characters allowed in a match will be less than
     the number passed in this parameter, as non-ASCII characters are represented by two or more bytes under the UTF-8 encoding scheme.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: The length of the longest match can affect the extraction performance. Defaults to 256.
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer.
    
    """


@_dll.export()
def EdkSetMaxMatchesPerDoc(pEngine: EdkEngineHandle, nMaxMatchesPerDoc: c_size_t) -> None:
    r"""  Sets the maximum number of matches per document.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param nMaxMatchesPerDoc: An integer denoting the maximum number of matches per document.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: When set to a positive integer, eduction will stop at that number of matches per document. The default value is zero, meaning no limit.
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer.
    
    """


@_dll.export()
def EdkSetMatchWholeWord(pEngine: EdkEngineHandle, bEnable: EdkBool) -> None:
    r"""  Selects the MatchWholeWord mode for the engine.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param bEnable: A Boolean, that if true, enables whole word matching. If set to false, it is disabled, and set to substring matching. The default is true.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: Whole word mode defines how the engine matches entities. In whole word mode all entity matches begin and end at a word boundary;
     in substring mode an entity can begin and/or end anywhere, including in the middle of a word. For more information, see the Eduction Programming Guide.
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer.
    
    """


@_dll.export()
def EdkSetTokenWithPunctuation(pEngine: EdkEngineHandle, bEnable: EdkBool) -> None:
    r"""  Selects the Token With Punctuation mode for the engine.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param bEnable: A Boolean, that if true, enables token with punctuation. If set to false, it is disabled. The default is false.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: This only applies in Whole word mode. In a whole word mode all entity matches begin and end at a word boundary. This setting allows punctuation
     to be considered as part of a token, regardless of where it occurs in the token. For more information, see the Eduction Programming Guide.
    .. seealso:: :any:`EdkSetMatchWholeWord` :any:`EdkSetTangibleCharacters`
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer.
    
    """


@_dll.export()
def EdkSetTangibleCharacters(pEngine: EdkEngineHandle, szTangibleCharacters: c_char_p) -> None:
    r"""  Sets the tangible characters.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param szTangibleCharacters: A string pointing to a list of characters.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: This sets a list of non-alphanumeric characters that should be treated as part of a token (i.e. not a word boundary).
    .. seealso:: :any:`EdkSetTokenWithPunctuation`
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer.
    
    """


@_dll.export()
def EdkSetAllowOverlaps(pEngine: EdkEngineHandle, bEnable: EdkBool) -> None:
    r"""  Selects the Overlaps match mode for the engine.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param bEnable: A Boolean, that if true, enables overlap matching. If set to false, it is disabled. The default is false.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: Allow overlaps mode defines how the engine matches entities. If overlaps are allowed, entity matches can overlap on the same piece of text;
     if overlap is disabled, only the 'best' highest-scoring entity match is returned, and the search for matches will resume at the end of the returned entity.
     'Best' means either longest or shortest match, depending on whether greedy mode is used. For more information, see the Eduction Programming Guide.
    .. seealso:: :any:`EdkSetNonGreedyMatch`
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer.
    
    """


@_dll.export()
def EdkSetAllowMultipleResults(pEngine: EdkEngineHandle, szAllowMultipleResults: c_char_p) -> None:
    r"""  Selects the Multiple results match mode for the engine.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param szAllowMultipleResults: A string pointing to a setting. 
     If set to "All", enables each entity to return multiple matched results for a given offset. If set to "OnePerEntity", enables each entity to return at most one result for a given offset. 
     If set to "No", which is the default, only one result for a given offset (across all used entities) is returned.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: Determine if entities are allowed to return multiple results.
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer.
    
    """


@_dll.export()
def EdkSetNonGreedyMatch(pEngine: EdkEngineHandle, bEnable: EdkBool) -> None:
    r"""  Selects the non-greedy match mode for the engine.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param bEnable: A Boolean, that if true, sets the non-greedy match mode so the shortest match is returned. The default is false.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: Sets the non-greedy mode so the shortest match is returned. By default, the longest match is returned.
             For more information, see the Eduction Programming Guide.
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer.
    
    """


@_dll.export()
def EdkSetPrioritizeScore(pEngine: EdkEngineHandle, bEnable: EdkBool) -> None:
    r"""  Selects the prioritize score match mode for the engine.
    
     :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
     :param bEnable: A Boolean, that if true, sets the prioritize score match mode so that score takes precedence over length for matches.
     :raises: A standard :exc:`~edk.error.EdkException` if it fails.
     .. note:: Sets the prioritize score mode so that score takes precedence over length for matches. By default length takes precedence 
              (either longer or shorter based on the NonGreedyMatch setting).
     .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer. 
    
    """


@_dll.export()
def EdkSetMatchCase(pEngine: EdkEngineHandle, bEnable: EdkBool) -> None:
    r"""  Selects the Case match mode for the engine.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param bEnable: A Boolean, that if true, enables case sensitive matching. If set to false, it sets to case insensitive mode. The default is true.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: Allow case match mode defines how the engine matches entities. By default, input text must match the entity definitions exactly (including case) to return matches.
             For more information, see the Eduction Programming Guide.
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer.
    
    """


@_dll.export()
def EdkSetCaseNormalization(pEngine: EdkEngineHandle, eMode: EdkCaseNormalization) -> None:
    r"""  Selects the input case normalization mode for the engine.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param eMode: An enum that specifies how the input text provided to a session from this engine (via either EdkAddInputText or EdkSetInputStream) will be normalized 
     prior to being examined for matches.
    .. note:: EdkCaseNormalization:any:`original` leaves the text unchanged, EdkCaseNormalization:any:`upper` converts the text to uppercase, and 
             EdkCaseNormalization:any:`lower` converts the text to lowercase.
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer.
    
    """


@_dll.export()
def EdkSetCaseNormalizationBehaviour(pEngine: EdkEngineHandle, eBehaviour: EdkCaseNormalizationBehaviour) -> None:
    r"""  Selects the input case normalization behavior for the engine.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param eBehaviour: An enum that specifies what case normalization rules will be applied to the input text provided to a session from this engine (via either EdkAddInputText or EdkSetInputStream)
     prior to being examined for matches.
    .. note:: EdkCaseNormalizationBehaviour:any:`turkic` applies Turkic rules when normalizing text, and EdkCaseNormalizationBehaviour:any:`normal` applies standard rules.
    .. seealso:: :any:`EdkSetCaseNormalization`
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer.
    
    """


@_dll.export()
def EdkEngineSetCJKNormalization(pEngine: EdkEngineHandle, szCJKNormalizationOptions: c_char_p) -> None:
    r"""  Selects the input CJK normalization behavior for the engine.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param szCJKNormalizationOptions: A CSV of CJK normalization options. Valid elements are "Kana" (half width kana to full width kana), 
                                                                                            "OldNew" (old kanji to new kanji), 
                                                                                            "SimpChi" (traditional Chinese to simplified Chinese),
                                                                                            "Number" (Chinese/kanji numbers to ASCII numbers), 
                                                                                            "HWAlpha" (full width alphabet characters to ASCII characters), 
                                                                                            "HWNum" (full width number characters to ASCII characters) and 
                                                                                            "FWJamo" (half width jamo to full width jamo).
    .. note:: CJK normalization is applied to the input text provided to a session from this engine (via either EdkAddInputText or EdkSetInputStream) prior to being examined for matches.
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer.
    
    """


@_dll.export()
def EdkSetLanguageDirectory(pEngine: EdkEngineHandle, szLanguageDirectory: c_char_p) -> None:
    r"""  Set the language directory setting for the engine.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param szLanguageDirectory: A string representing the path to the language directory.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: The string must be a path that specifies the directory that contains the language data files. These are used to perform CJK normalization.
             For example, if an IDOLServer instance is available, this can be set to the langfiles directory of the IDOLServer instance.
             The default value is "langfiles".
    .. seealso:: :any:`EdkEngineSetCJKNormalization`
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer.
    
    """


@_dll.export()
def EdkLoadResourceFile(pEngine: EdkEngineHandle, szResourceFilePath: c_char_p) -> None:
    r"""  Load a grammar (resource) file into the engine.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`.
    :param szResourceFilePath: A string pointing to the grammar file.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: Grammar files contain entity (pattern) defintions to use for the extraction process.
             This function should be called once per grammar file to load. The file identified by szResourceFilePath 
             can be a compiled ECR file or an uncompiled XML file. In the latter case, the file will be compiled by
             the engine before it loads the definitions the file contains. Compilation does involve some overhead. 
             If the XML grammar contains errors, the function will return with a generic compiler error. To obtain 
             a more specific error message, use edktool in the distribution to compile the XML file.
    .. seealso:: :any:`EdkLoadResourceFileWithCompileConfig`
    .. seealso:: :any:`EdkLoadResourceBuffer`
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can specify the grammar file(s) to use in a suitable config file or buffer.
    
    """


@_dll.export()
def EdkLoadResourceFileWithCompileConfig(pEngine: EdkEngineHandle, szResourceFilePath: c_char_p, szCompileConfigPath: c_char_p) -> None:
    r"""  Load a grammar (resource) file into the engine with associated compilation configuration 
    
    :param pEngine: An :any:`EdkEngineHandle` previous allocated by a call to :any:`EdkFactoryMakeEngine`.
    :param szResourceFilePath: A string pointing to the grammar file.
    :param szCompileConfigPath: A string pointing to the compilation config JSON file to use.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: Grammar files contain entity (pattern) defintions to use for the extraction process.
             This function should be called once per grammar file to load. The file identified by szResourceFilePath 
             can be a compiled ECR file or an uncompiled XML file. In the latter case, the file will be compiled by
             the engine before it loads the definitions the file contains and the compilation configuration provided
             will be used. Compilation does involve some overhead. If the XML grammar contains errors, the function
             will return with a generic compiler error. To obtain a more specific error message, use edktool in the
             distribution to compile the XML file.
    .. seealso:: :any:`EdkLoadResourceFile`
    .. seealso:: :any:`EdkLoadResourceBuffer`
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can specify the grammar file(s) to use in a suitable config file or buffer.
    
    """


@_dll.export()
def EdkSaveResourceFile(pEngine: EdkEngineHandle, szResourceFilePath: c_char_p) -> None:
    r"""  Saves loaded grammars (resources) into a file.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param szResourceFilePath: A string pointing to the output grammar file.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: This function can be called to save a compiled version of all grammars loaded in the engine. The file 
             identified by szResourceFilePath will be a compiled ECR file. In case of error, and error code is 
             returned XML grammar contains errors, the function will return with a generic compiler error. To obtain 
             a more specific error message, use edktool in the distribution to compile the XML file.
    .. seealso:: :any:`EdkLoadResourceBuffer`
    
    """


@_dll.export()
def EdkLoadResourceBuffer(pEngine: EdkEngineHandle, bResourceBuffer: c_void_p, nSize: c_size_t) -> None:
    r"""   Load one or more grammars for the engine from a grammar (resource) buffer in memory.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param bResourceBuffer: A pointer to a byte buffer containing grammar data.
    :param nSize: The size of the buffer in bytes.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: Grammar files contain entity (pattern) defintions to use for the extraction process.
             This function should be called once per grammar buffer to load. The buffer identified
             by bResourceBuffer can contain a compiled ECR file or an uncompiled XML file. In the latter case, the 
             buffer will be compiled by the engine before it loads the definitions the buffer contains. Compilation does 
             involve some overhead. If the XML grammar contains errors, the function will return with a generic compiler 
             error. To obtain a more specific error message, use edktool in the distribution to compile the XML grammar.
    .. seealso:: :any:`EdkLoadResourceFile`
    
    """


@_dll.export()
def EdkLoadResourceBufferWithCompileConfig(pEngine: EdkEngineHandle, bResourceBuffer: c_void_p, nSize: c_size_t, szCompileConfigPath: c_char_p) -> None:
    r"""   Load one or more grammars for the engine from a grammar (resource) buffer in memory, using a compilation config.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param bResourceBuffer: A pointer to a byte buffer containing grammar data.
    :param nSize: The size of the buffer in bytes.
    :param szCompileConfig: Path to a compilation config to use
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: Grammar files contain entity (pattern) defintions to use for the extraction process.
             This function should be called once per grammar buffer to load. The buffer identified
             by bResourceBuffer can contain a compiled ECR file or an uncompiled XML file. In the latter case, the 
             buffer will be compiled by the engine before it loads the definitions the buffer contains and the compilation 
             configuration provided will be used. Compilation does involve some overhead. If the XML grammar contains 
             errors, the function will return with a generic compiler error. To obtain a more specific error message, 
             use edktool in the distribution to compile the XML grammar.
    .. seealso:: :any:`EdkLoadResourceFile`
    
    """


@_dll.export()
def EdkAddTargetEntity(pEngine: EdkEngineHandle, szEntityName: c_char_p) -> None:
    r"""  Sets a CSV of entities that should be used for matching by the engine.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`.
    :param szEntityName:  The entities to use, as a CSV. Elements can use wildcards (? or *) if needed.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: The entities referred by szEntityName must appear in the grammars loaded by :any:`EdkLoadResourceFile` or :any:`EdkLoadResourceBuffer`.
             :any:`EdkAddTargetEntity` cannot be called after a session has been created using :any:`EdkSessionCreate`.
    .. seealso:: :any:`EdkLoadResourceFile` :any:`EdkLoadResourceBuffer`
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can specify the entities to use in a suitable config file or buffer.
    
    """


@_dll.export()
def EdkGetEntities(pEngine: EdkEngineHandle, paszEntities: POINTER(POINTER(c_char_p))) -> c_int:
    r"""  Returns all public entities available in the grammars used by this engine.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param paszEntities: A pointer to an array of strings; this is filled with the available entities. Allocated memory should be released by calling :any:`EdkFreeStringArray`.
    :return: The size of the paszEntities array.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: The returned entities are those exposed by the grammars currently in this engine. These are not necessarily the ones that will be used. Use EdkAddTargetEntity to select the entities to use.
    .. seealso:: :any:`EdkFreeStringArray`
    
    """


@_dll.export()
def EdkEngineAddPostProcessingTask(pEngine: EdkEngineHandle, szTaskName: c_char_p, szScriptName: c_char_p, szEntitiesCSV: c_char_p, bProcessEnMasse: EdkBool) -> None:
    r"""  Adds a post processing task to the engine.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param szTaskName: A name for the task. Should be unique, to enable tasks to be identified in task collections.
    :param szScriptName: The path to the Lua script that the task will run. Can be relative or absolute.
    :param szEntitiesCSV: A CSV of entities. The task will only be run on matches for an entity within this CSV. Elements can use wildcards (? or *) if needed.
    :param bProcessEnMasse: Whether the script processes the matches en masse. If it does, the script should define a processmatches function, rather than processmatch. This function will receive
                             all matches found as a table of objects, rather than a single match object.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: Any session created from an engine that contains post-processing tasks will automatically run those tasks on prospective matches before returning them.
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can specify the post-processing tasks to run in a suitable config file.
    
    """


@_dll.export()
def EdkEngineSetPostProcessingThreshold(pEngine: EdkEngineHandle, dThreshold: c_double) -> None:
    r"""  Sets the post processing threshold for this engine.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param dThreshold: The threshold to set. Any matches with a score less than this after running all post-processing tasks will be discarded.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: The threshold must be positive.
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer.
    
    """


@_dll.export()
def EdkEngineSetLoggingFn(pEngine: EdkEngineHandle, loggingFn: EdkLoggingFn) -> None:
    r"""  Sets the logging function for this engine. This callback receives a user data parameter.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param loggingFn: The logger function (of type :any:`EdkLoggingFn`) to use.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: The logger function will be called for noteworthy events (for example, if an error occurs when running post processing tasks).
    .. seealso:: :any:`EdkEngineSetLoggingUserData`
    
    """


@_dll.export()
def EdkEngineSetLoggingUserData(pEngine: EdkEngineHandle, pUserData: py_object) -> None:
    r"""  Sets the logging function user data parameter for this engine.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param pUserData: The user data to be used by the logging function set by :any:`EdkEngineSetLoggingFn`.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: The user data will be passed as the first argument to the function set by :EdkEngineSetLoggingFn whenever the latter is called.
    .. seealso:: :any:`EdkEngineSetLoggingFn`
    
    """


@_dll.export()
def EdkSessionCreate(pEngine: EdkEngineHandle, ppSession: POINTER(session.EdkSessionHandle)) -> None:
    r"""  Creates an EDK session for processing an input document.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param ppSession: A pointer to an :any:`EdkSessionHandle`. If the session can be created, the pointer is set to the new session on return. If no session is created, the pointer is set to NULL.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: An EDK session is used for processing documents. You can create multiple EDK sessions for one EDK engine.
             Each session can be used to process a data stream (of multiple documents) concurrently with other sessions
             or data streams all sharing a common engine (and associated grammars/settings). Each session has its own state.
             Note that all engine configuration should be completed before calling :any:`EdkSessionCreate`.
    .. seealso:: :any:`EdkFactoryMakeEngine` :any:`EdkFactoryMakeEngineFromConfigFile` :any:`EdkFactoryMakeEngineFromConfigBuffer` :any:`EdkSessionDestroy`
    
    """


@_dll.export()
def EdkSessionCreateWithConfigBuffer(pEngine: EdkEngineHandle, ppSession: POINTER(session.EdkSessionHandle), szConfigBuffer: c_char_p) -> None:
    r"""  Creates an EDK session for processing an input document, with customized configuration.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param ppSession: A pointer to an :any:`EdkSessionHandle`. If the session can be created, the pointer is set to the new session on return. If no session is created, the pointer is set to NULL.
    :param szConfigBuffer: A string containing a partial eduction config in memory.
           This may set (only) those standard eduction configuration parameters that may be overridden on
           a per-session basis, for example MinScore -- refer to the documentation for a comprehensive list.
           Settings not specified here will be inherited from the engine configuration state, as usual.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
            In particular, raises :exc:`~edk.error.EdkConfigErrorException` if any configuration parameter is invalid, or cannot be
            overridden for an individual session.
    .. note:: An EDK session is used for processing documents. You can create multiple EDK sessions for one EDK engine.
             Each session can be used to process a data stream (of multiple documents) concurrently with other sessions
             or data streams all sharing a common engine (and associated grammars/settings). Each session has its own state.
             Note that all engine configuration should be completed before calling :any:`EdkSessionCreate`.
    .. seealso:: :any:`EdkFactoryMakeEngine` :any:`EdkFactoryMakeEngineFromConfigFile` :any:`EdkFactoryMakeEngineFromConfigBuffer` :any:`EdkSessionDestroy`
    
    """


@_dll.export(errhandler=True)
def EdkGetLastEngineError(pEngine: EdkEngineHandle) -> tuple[EdkError,c_char_p]:
    r"""  Returns the latest error code from this engine.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :return: A tuple containing:
        A standard :any:`EdkError` value corresponding to the last error of the engine.
        A string buffer to hold the error message.
    
    """


@_dll.export()
def EdkRedactText(pEngine: EdkEngineHandle, szBuffer: c_char_p, pszText: POINTER(c_char_p)) -> None:
    r"""  Returns a redacted version of the input text based on the extraction results.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param szBuffer: A handle to an input text buffer. The buffer must be UTF-8 encoded.
    :param pszText: A pointer to the handle of the redacted text. This should be released with :any:`EdkFreeBuffer` once no longer required.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. note:: Any part of the input string that matches a configured entity will be replaced by the redaction replacement string in the produced redacted text.
             To change the redaction replacement string, create an engine from a config file that sets the RedactionOutputString parameter.
    
    """


@_dll.export()
def EdkSetMinScore(pEngine: EdkEngineHandle, dScore: c_double) -> None:
    r"""  Sets the minimum score required for a matching entity.
    
    :param pEngine: An :any:`EdkEngineHandle` previously allocated by a call to :any:`EdkFactoryMakeEngine`, :any:`EdkFactoryMakeEngineFromConfigFile`, or :any:`EdkFactoryMakeEngineFromConfigBuffer`.
    :param dScore: The minimum score to be used. Any match with a score lower than this (before running any post-processing tasks) will be discarded.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    .. seealso:: :any:`EdkFactoryMakeEngineFromConfigFile` and :any:`EdkFactoryMakeEngineFromConfigBuffer` can set this via a suitable config file or buffer.
    
    """


@_dll.export()
def EdkGetMatchCounts(pEngine: EdkEngineHandle, szBuffer: c_char_p, paszEntityNames: POINTER(POINTER(c_char_p)), panMatchCounts: POINTER(POINTER(c_size_t))) -> c_int:
    r"""  Gets per-entity counts of matches for the given engine and text buffer.
     Produces parallel arrays of entity names and match counts in *paszEntityNames and *panMatchCounts respectively
     i.e. for i 0 <= i < *pnEntities, (*panMatchCounts)[i] is the match count for the entity with name (*paszEntityNames)[i].
    
     :param pEngine: A :any:`EdkEngineHandle` that has been previously created.
     :param szBuffer: The text buffer to get per-entity match counts from.
     :param paszEntityNames: Pointer to where an array of char strings - representing the names of entities that produced matches - will be created.
     :param panMatchCounts: Pointer to where an array of size_t - representing the counts of matches - will be created.
     :return: An int where the count of entries in the parallel arrays will be placed, i.e. the length of the generated arrays.
     :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    
     .. note:: **Precondition**: pEngine has been created.
     .. note:: **Precondition**: szBuffer points to a valid NULL-terminated character array.
     .. note:: **Precondition**: paszEntityNames != NULL and *paszEntityNames == NULL.
     .. note:: **Precondition**: panMatchCounts != NULL and *panMatchCounts == NULL.
     .. note:: **Precondition**: pnEntities != NULL.
    
     .. note:: **PostCondition**: If successful and there are matches: *pnEntities > 0, *paszEntityNames is an array of char* with length *pnEntities, *panMatchCounts is an array of size_t with length *pnEntities.
     .. note:: **PostCondition**: If successful there are no matches: *pnEntities == 0, *paszEntityNames == NULL, *panMatchCounts == NULL.
     .. note:: **PostCondition**: If not successful: *pnEntities == 0, *paszEntityNames == NULL, *panMatchCounts == NULL.
    
    """


def EdkSetLoggingCallback(engine: EdkEngineHandle, callback: Callable[[int, bytes], None]) -> None:
    r""" Sets a callback to handle logging output from Eduction.
    
    :param engine: An :class:`EdkEngineHandle` previously allocated by a call to :func:`EdkEngineCreate`.
    :param callback: Callable python object that will be called with a log level and message bytes.
    :raises: A standard :exc:`~edk.error.EdkException` if it fails.
    """
    if not callable(callback):
        raise TypeError("EdkSetLoggingCallback requires a callable object")
    EdkEngineSetLoggingFn(engine, EdkLoggingFn())
    EdkEngineSetLoggingUserData(engine, py_object(callback))
    return EdkEngineSetLoggingFn(engine, _logging._invoke_callback)

