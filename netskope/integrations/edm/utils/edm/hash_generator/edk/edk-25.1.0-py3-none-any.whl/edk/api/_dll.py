###
# Copyright 2023 Open Text.
# 
# The only warranties for products and services of Open Text and its
# affiliates and licensors ("Open Text") are as may be set forth in the
# express warranty statements accompanying such products and services.
# Nothing herein should be construed as constituting an additional warranty.
# Open Text shall not be liable for technical or editorial errors or omissions
# contained herein. The information contained herein is subject to change
# without notice.
# 
# Except as specifically indicated otherwise, this document contains
# confidential information and a valid license is required for possession, use
# or copying. If this work is provided to the U.S. Government, consistent with
# FAR 12.211 and 12.212, Commercial Computer Software, Computer Software
# Documentation, and Technical Data for Commercial Items are licensed to the
# U.S. Government under vendor's standard commercial license.
###
import ctypes
import ctypes.util
import collections
import functools
import inspect
import os
import typing

from . import types, _ctypesmapping, _error
from .. import error


class EdkDll:
    """
    Loads the Eduction shared library and provides bindings using ctypes.
    """

    def __init__(self):
        edkpath = os.environ.get('EDKLIBPATH', ctypes.util.find_library('edk'))
        if edkpath is None:
            raise ImportError("Failed to locate EDK shared library")
        elif not os.path.exists(edkpath):
            raise ImportError(f"Failed to locate EDK shared library at '{edkpath}'")
        handle = None
        if os.name == 'nt':
            # N.B. winmode parameter introduced in Python 3.8
            for winmode in (0, 0x8, 0x1100):
                # 0x0080: LOAD_WITH_ALTERED_SEARCH_PATH
                # 0x0100: LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR
                # 0x1000: LOAD_LIBRARY_SEARCH_DEFAULT_DIRS
                try:
                    handle = ctypes.CDLL(edkpath, winmode=winmode)
                    break
                except (FileNotFoundError, OSError):
                    continue # try next winmode
                except TypeError:
                    break # no sense trying again
        if handle is None:
            # Not Windows, or no success with winmode parameter
            handle = ctypes.CDLL(edkpath)
        # Retrieve and store DLL's version information
        self._handle = handle
        self._set_version()

    @staticmethod
    def _getlasterrorstring(function_result, calling_args):
        if calling_args and calling_args[0]:
            handle = calling_args[0]
            if hasattr(handle, '_as_parameter_'):
                handle = handle._as_parameter_
            getlasterror = getattr(type(handle), 'getlasterror', None)
            if getlasterror:
                err, errstr = getlasterror(handle)
                if err == function_result:
                    return errstr.decode()

    @staticmethod
    def _handle_edkerror(code, func, args):
        fn = func.__name__
        if code != _error.EdkErrorCode.EDKSUCCESS.value:
            msg = EdkDll._getlasterrorstring(code, args)
            raise error.EdkException(code, fname=fn, message=msg)

    def _get_edk_fn(self, name, argtypes, errcheck=True):
        fn = getattr(self._handle, name)
        fn.restype = types.EdkError
        if errcheck:
            fn.errcheck = self._handle_edkerror
        fn.argtypes = argtypes
        return fn

    EdkVersionInfo = collections.namedtuple('EdkVersionInfo',
        ('copyright', 'buildtime', 'string', 'number'))
        
    def _set_version(self):
        info = types.EDK_VERSION_INFO()
        edkgetversion = self._get_edk_fn('EdkGetVersion', (ctypes.POINTER(types.EDK_VERSION_INFO),))
        edkgetversion(ctypes.byref(info))
        self._version = self.EdkVersionInfo(
            info.copyright.decode(), info.buildTime.decode(), info.versionString.decode(),
            (info.vMajor, info.vMinor, info.vChangeSet)
        )

    @property
    def version(self):
        return self._version

    _OutParam = collections.namedtuple('_OutParam', ('pos', 'type'))

    def export(self, *, outpos=None, errhandler=False, minversion=None):

        if minversion is not None and minversion > self.version.number:
            def not_impl_decorator(dummyfn):
                msg = "{fn} requires EDK version {rqv} or later (reports {rpv})".format(
                    fn=dummyfn.__name__, rqv='.'.join(map(str,minversion)), rpv=self.version.string)
                def not_impl(*args):
                    raise NotImplementedError(msg)
                functools.update_wrapper(not_impl, dummyfn)
                return not_impl
            return not_impl_decorator

        def decorator(signature):
            sig = inspect.signature(signature)
            argstypes = [p.annotation for p in sig.parameters.values()]
            outparam = sig.return_annotation

            if isinstance(outparam, typing.GenericAlias) and outparam.__origin__ is tuple:
                outparam = outparam.__args__
                if errhandler:
                    outparam = outparam[1:]
            elif not outparam or outparam is sig.empty:
                outparam = tuple()
            else:
                outparam = (outparam,)

            rt = None

            if outpos is None:
                op = tuple(range(len(argstypes), len(argstypes)+len(outparam)))
            elif not isinstance(outpos, tuple):
                op = (outpos,)
            else:
                op = outpos
            for i,o in zip(op, outparam):
                argstypes.insert(i, ctypes.POINTER(o))
            fn = self._get_edk_fn(signature.__name__, argstypes, errcheck=not errhandler)

            if errhandler:
                if len(outparam) != 1:
                    raise AssertionError('Unhandled: error handler must have single output parameter, got {}'.format(argstypes))
                r = outparam[0]
                p = op[0]
                def handle_params(*args):
                    result = r()
                    ret = fn(*(args[:p] + (ctypes.byref(result),) + args[p:]))
                    return (ret, result.value)
                rt = tuple[types.EdkError, _ctypesmapping.map_param_type(r)]
            elif not outparam:
                def handle_params(*args):
                    fn(*args)
            elif len(outparam) == 1:
                r = outparam[0]
                p = op[0]
                def handle_params(*args):
                    result = r()
                    fn(*(args[:p] + (ctypes.byref(result),) + args[p:]))
                    return result.value
                if r in _ctypesmapping.CTYPES_MAPPING:
                    rt = _ctypesmapping.CTYPES_MAPPING[outparam[0]]
            elif len(outparam) == 2:
                r0, r1 = outparam[0], outparam[1]
                p0, p1 = op[0], op[1]
                def handle_params(*args):
                    result0 = r0()
                    result1 = r1()
                    fn(*(args[:p0] + (ctypes.byref(result0),) + args[p0:p1] + (ctypes.byref(result1),) + args[p1:]))
                    return result0.value, result1.value
                rt = tuple[tuple(map(_ctypesmapping.map_param_type, outparam))]
            else:
                raise AssertionError('Unhandled: multiple output parameters {}'.format(argstypes))

            if errhandler:
                handle_params.__signature__ = sig.replace(return_annotation=rt)
                handle_params.__annotations__['return'] = rt
                handle_params.__doc__ = f'''Returns the latest error code from this {argstypes[0].__name__}'''
                argstypes[0].getlasterror = handle_params

            @functools.wraps(signature)
            def call_edk(*args):
                signature(*args)
                return handle_params(*args)

            if rt is not None:
                call_edk.__annotations__['return'] = rt
                call_edk.__signature__ = sig.replace(return_annotation=rt)

            return call_edk

        return decorator


edkdll = EdkDll()


def EdkGetVersion():
    """Return version information for the loaded Eduction shared library"""
    return edkdll.version
