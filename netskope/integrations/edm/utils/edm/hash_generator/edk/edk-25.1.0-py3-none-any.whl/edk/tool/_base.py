###
# Copyright 2023 Open Text.
# 
# The only warranties for products and services of Open Text and its
# affiliates and licensors ("Open Text") are as may be set forth in the
# express warranty statements accompanying such products and services.
# Nothing herein should be construed as constituting an additional warranty.
# Open Text shall not be liable for technical or editorial errors or omissions
# contained herein. The information contained herein is subject to change
# without notice.
# 
# Except as specifically indicated otherwise, this document contains
# confidential information and a valid license is required for possession, use
# or copying. If this work is provided to the U.S. Government, consistent with
# FAR 12.211 and 12.212, Commercial Computer Software, Computer Software
# Documentation, and Technical Data for Commercial Items are licensed to the
# U.S. Government under vendor's standard commercial license.
###
import re
from argparse import ArgumentParser, Action, Namespace

from ..sdk import EdkFactory, EdkEngine

class EdkToolModuleBase:

    @classmethod
    def main(cls) -> None:
        parser = ArgumentParser('edk.tool.{}'.format(cls.command))
        cls.add_arguments(parser)
        args = parser.parse_args()
        cls(args).run()

    @classmethod
    def register(cls, subparsers : Action) -> None:
        subparser = subparsers.add_parser(cls.command,
                        aliases=getattr(cls, 'aliases', []),
                        help=getattr(cls, 'help'))
        cls.add_arguments(subparser)
        subparser.set_defaults(cls=cls)

    @classmethod
    def add_arguments(cls, parser : ArgumentParser) -> None:
        parser.add_argument('-l', '--licensefile', required=True, help='License path')

    def __init__(self, args : Namespace) -> None:
        try:
            with open(args.licensefile, 'rb') as keyfile:
                self.license = keyfile.read()
        except FileNotFoundError:
            if re.search(r'[^A-Za-z0-9+/=;]', args.licensefile):
                raise
            self.license = args.licensefile

    def get_factory(self) -> EdkFactory:
        return EdkFactory.create_with_license_key(self.license)


class EdkToolModuleWithConfig(EdkToolModuleBase):

    @classmethod
    def add_arguments(cls,  parser : ArgumentParser) -> None:
        super().add_arguments(parser)
        cfggroup = parser.add_argument_group('Eduction configuration')
        group = cfggroup.add_mutually_exclusive_group(required=True)
        group.add_argument('-c', '--configfile', help='Configuration file')
        # Ideally -g+-e would be grouped together under the mutually_exclusive_group,
        # but add_argument_group() ... on a mutually exclusive group is deprecated.
        group.add_argument('-g', '--grammarfile', nargs='+', help='Grammar file path')
        cfggroup.add_argument('-e', '--entity', nargs='+', default='*', help='Entities to use (default: all public entities)')

    def __init__(self, args : Namespace) -> None:
        super().__init__(args)
        self.configfile = args.configfile
        self.grammars = args.grammarfile
        self.entities = args.entity

    def get_engine(self, factory : EdkFactory) -> EdkEngine:
        if self.configfile:
            return factory.engine(configpath=self.configfile)
        engine = factory.engine()
        for g in self.grammars:
            engine.load(grammarpath=g)
        if self.entities:
            engine.add_target_entities(*self.entities)
        return engine


class EdkToolModuleWithInput(EdkToolModuleBase):

    @classmethod
    def add_arguments(cls,  parser : ArgumentParser) -> None:
        super().add_arguments(parser)
        inputgroup = parser.add_mutually_exclusive_group(required=True)
        inputgroup.add_argument('-i', '--inputfile', help='Input file')
        inputgroup.add_argument('-t', '--inputtext', help='Input text')

    def __init__(self, args : Namespace) -> None:
        super().__init__(args)
        self.inputfile = args.inputfile
        self.inputtext = args.inputtext
