###
# Copyright 2024 Open Text.
# 
# The only warranties for products and services of Open Text and its
# affiliates and licensors ("Open Text") are as may be set forth in the
# express warranty statements accompanying such products and services.
# Nothing herein should be construed as constituting an additional warranty.
# Open Text shall not be liable for technical or editorial errors or omissions
# contained herein. The information contained herein is subject to change
# without notice.
# 
# Except as specifically indicated otherwise, this document contains
# confidential information and a valid license is required for possession, use
# or copying. If this work is provided to the U.S. Government, consistent with
# FAR 12.211 and 12.212, Commercial Computer Software, Computer Software
# Documentation, and Technical Data for Commercial Items are licensed to the
# U.S. Government under vendor's standard commercial license.
###
__all__ = ['EdkFactory', 'EdkEngine', 'EdkSession']


import enum
import io
import json
import numbers
import time
import uuid
import warnings

from collections.abc import Iterable, Iterator, MutableMapping, Sequence
from typing import Any, Optional

from . import api, error
from ._sdk import callbacks, decorators, matchimpl
from ._sdk.base import EdkHandleBase
from ._sdk.results import EdkBuffer, EdkStringArray, EdkMatchCounts
from .typehints import (
    ByteLike, StringLike,
    Configuration, PathToFile, PointInTime,
    InputCallback, LogCallback, Loggable,
    MatchLike
)


@decorators.AutoMethods(api.session,
                        r'EdkGet(MatchComponent(?!Count)\w+)', lambda m:'current' + m[1])
@decorators.AutoGetProps(api.session,
                         r'EdkGet(\w*Match(?:ComponentCount|(?!Component)\w+))', lambda m:'current' + m[1])
@decorators.AutoSetProps(api.session,
                         r'EdkSessionSet(?!UserParam)(?!Entity)(\w+)(?<!Precise)(?<!Time)', lambda m:m[1])
@decorators.AutoSetMillisecondProps(api.session,
                                    r'EdkSessionSet(\w+Time(?:outPrecise)?)', lambda m:m[1].replace('Precise',''))
class EdkSession(EdkHandleBase):
    """
    The actual processing of the data is done in an eduction session. Multiple sessions can
    be created for an eduction engine. All sessions associated with an engine process data
    using the configuration set for that engine, including grammars and entities. Each session 
    maintains its own state, so the sessions can be run concurrently in a multithreaded 
    application.

    Once created, a session can be used to process multiple documents. Data must be UTF-8
    encoded (if provided as raw bytes; Python strings will be automatically encoded).
    Data can either be pulled (streamed) or pushed (added). The session can be iterated 
    over to cycle through all the matches.

    A session can live for as long as necessary. It must, however, be destroyed before the
    engine it is associated with is destroyed.
    """
    _handletype = api.session.EdkSessionHandle
    _destructor = staticmethod(api.session.EdkSessionDestroy)
    __slots__ = ('_input_callback', 'input_mode', 'persistent_matches', 'repeated_matches')

    _input_callback: InputCallback

    class InputMode(enum.Enum):
        """ Distinguish byte-mode from text-mode input """
        BYTES = True
        "Data is transferred as UTF-8 encoded bytes. Reported offsets are byte counts."
        TEXT = False
        "Data is transferred as Python strings. Reported offsets are Unicode character counts."

    input_mode: InputMode
    """
    The type (text or bytes) of the last input added to the session.
    Text in returned match objects will be of the corresponding type,
    and offsets either Unicode character or byte counts, respectively.
    """
    persistent_matches: bool
    """
    If set, return match objects with persistent copies of all data.
    Otherwise, requests for match object properties are passed to the
    session, which returns the value for the current match (so should
    only be referenced until the session is advanced to the next match).
    """
    repeated_matches: bool
    """
    If set, for each match, first iterate over any occurrences of the
    same string in the input data, using Eduction's "Repeated Match"
    functionality, before continuing to find the next (distinct) match.
    """

    @property
    def text_mode(self) -> bool:
        """ True if input has been as text (as opposed to bytes) """
        return (getattr(self, 'input_mode', self.InputMode.TEXT) is self.InputMode.TEXT)

    @property
    def input_stream(self) -> io.IOBase:
        """
        Set session to read input from `stream`.
        This attribute cannot be read, only assigned.
        """
        raise AttributeError("The `input_stream` attribute cannot be read; assign an IO stream for the session to read from.")
    @input_stream.setter
    def input_stream(self, stream:io.IOBase) -> None:
        if hasattr(self, '_input_callback'):
            raise RuntimeError("Repeated call to set EdkSession.input_stream")
        elif isinstance(stream, io.BufferedIOBase):
            self.input_mode = self.InputMode.BYTES
            self._input_callback = callbacks.BytesInputCallback(stream)
        elif isinstance(stream, io.TextIOBase):
            self.input_mode = self.InputMode.TEXT
            self._input_callback = callbacks.TextInputCallback(stream)
        else:
            raise ValueError("Not a text or binary stream")
        api.session.EdkSetInputCallback(self, self._input_callback)

    def reset(self) -> None:
        """
        Resets the state of the session, leaving it ready to receive new input.
        """
        api.session.EdkResetInputText(self)
        if hasattr(self, '_input_callback'):
            del self._input_callback
        if hasattr(self, 'input_mode'):
            del self.input_mode

    def _to_bytes_set_input_mode(self, text:StringLike) -> ByteLike:
        if self._is_bytes(text):
            self.input_mode = self.InputMode.BYTES
        else:
            try:
                text = text.encode('utf-8')
            except Exception:
                raise TypeError("Input must be UTF-8 bytes or Unicode text.")
            self.input_mode = self.InputMode.TEXT
        return text

    def add_input_text(self, text:StringLike, final:bool=False) -> None:
        """ Add `text` to the session input """
        text = self._to_bytes_set_input_mode(text)
        api.session.EdkAddInputText(self, text, len(text), final)

    def add_table_cell(self, text:StringLike, *, colspan:int=1, offset:Optional[int|Sequence[int]]=None) -> None:
        """ Add text `cell` as a new table cell """
        text = self._to_bytes_set_input_mode(text)
        if isinstance(offset, numbers.Number):
            offset = api.EdkOffset(codepoints=offset) if self.text_mode else api.EdkOffset(bytes=offset)
        elif isinstance(offset, Sequence):
            offset = api.EdkOffset(*offset)
        api.session.EdkAddTableCell(self, text, len(text), colspan, offset)

    def add_table_row(self, cells:Iterable[StringLike], final:bool=False) -> None:
        """ Add a whole row of table cells """
        current,curspan = '',0
        for col in cells:
            if col is not None:
                if curspan > 0:
                    self.add_table_cell(current, colspan=curspan)
                current,curspan = col,1
            else:
                curspan = curspan + 1
        if curspan > 0:
            self.add_table_cell(current, colspan=curspan)
        self.end_table_row(final=final)

    def end_table_row(self, final:bool=False) -> None:
        """ (When calling `add_table_cell`) indicate the current row is finished """
        api.session.EdkEndTableRow(self, final)

    def _check_timeout(self) -> None:
        if self.current_match_timed_out:
            warnings.warn("Match timed out", category=error.EdkTimeOutWarning)

    def _make_match_object(self, repeated:bool=False) -> MatchLike[str]|MatchLike[bytes]:
        self._check_timeout()
        match_cls = (
            (matchimpl.ProxyMatchString if self.text_mode else matchimpl.ProxyMatchBytes)
                if not repeated else
            (matchimpl.ProxyRepeatedMatchString if self.text_mode else matchimpl.ProxyRepeatedMatchBytes)
        )
        match = match_cls(self)
        if getattr(self, 'persistent_matches', False):
            match = match.persist()
        return match

    def __iter__(self) -> Iterator[MatchLike[str]|MatchLike[bytes]]:
        try:
            while True:
                api.session.EdkGetNextMatch(self)
                yield self._make_match_object()
                try:
                    while getattr(self, 'repeated_matches', False):
                        api.session.EdkGetNextRepeatedMatch(self)
                        yield self._make_match_object(repeated=True)
                except error.EdkNoMatchException:
                    pass
        except error.EdkNoMatchException:
            self._check_timeout()

    class __UserParams:
        """ Proxy setting of named user parameter values to the EDK session """
        def __init__(self, session:'EdkSession') -> None:
            self.session = session
        def __getitem__(self, _:Any) -> None:
            raise TypeError("EdkSession parameters can only be set")
        def __setitem__(self, k:StringLike, v:StringLike|numbers.Number) -> None:
            if isinstance(v, numbers.Number): v = str(v)
            session = self.session
            api.session.EdkSessionSetUserParamValue(session, session._to_bytes(k), session._to_bytes(v))

    @property
    def parameters(self) -> MutableMapping[StringLike,StringLike|numbers.Number]:
        """ Pass custom parameters to post-processing by setting `parameters[key] = value` """
        return self.__UserParams(self)

    class __EntityMatchLimits:
        """ Proxy setting of named entity match limits to the EDK session """
        def __init__(self, session:'EdkSession') -> None:
            self.session = session
        def __getitem__(self, _:Any) -> None:
            raise TypeError("EdkSession entity match limits can only be set")
        def __setitem__(self, entity:StringLike, n:int) -> None:
            session = self.session
            api.session.EdkSessionSetEntityMatchLimit(session, session._to_bytes(entity), n)

    @property
    def match_limit(self) -> MutableMapping[StringLike,int]:
        """ Configure custom match limits by setting `match_limit[entity_name] = N` """
        return self.__EntityMatchLimits(self)

    def start_request(self) -> None:
        """ Set request start time to the current time """
        self.start_time = time.time()


@decorators.AutoSetProps(api.engine, r'Edk(?:Engine)?Set(?!Log)(.*)', lambda m:m[1])
class EdkEngine(EdkHandleBase):
    """
    The core of the Eduction SDK is an eduction engine. The recommended way to create an engine
    is by using an engine factory.

    Once created, an engine can be optionally configured to determine its matching behavior.
    If an engine was created from a config file, no further configuration is needed, as it
    will already reflect the settings given in that file. In both cases, the engine will have
    been correctly licensed using the key supplied to the factory.
    
    One or more grammar files must be loaded into the engine. At least one entity exposed by
    the loaded grammars must be specified, to tell the engine what patterns to search for in
    the input text. Again, if the engine was created from a config file, all grammars and
    entities given in that file will be loaded automatically at creation time.

    The actual processing of the data is done in an eduction session. Multiple sessions can
    be created for an eduction engine. All sessions associated with an engine process data
    using the configuration set for that engine, including grammars and entities. Each session 
    maintains its own state, so the sessions can be run concurrently in a multithreaded 
    application.
    """
    _handletype = api.engine.EdkEngineHandle
    _destructor = staticmethod(api.engine.EdkEngineDestroy)
    __slots__ = ('_log_callback',)

    _log_callback: LogCallback

    def session(self, *,
                config:Optional[Configuration]=None,
                input:Optional[StringLike|io.IOBase]=None,
                start_time:Optional[bool|PointInTime]=None
                ) -> EdkSession:
        """
        Create a new Eduction session, to perform matching.

        Optionally, supply:
          * a config fragment, with per-session settings to override engine configuration,
            as either a plain text buffer, or configparser.ConfigParser object;
          * an input stream, or input string/buffer, to set on the session;
          * a start time that will be used by the session to manage request timeout,
            as either a datetime.datetime or a numeric epoch timestamp, or `True` to
            set to the current time.
        """
        if config:
            session = EdkSession(api.engine.EdkSessionCreateWithConfigBuffer, self, ..., self._to_bytes(config))
        else:
            session = EdkSession(api.engine.EdkSessionCreate, self)
        try:
            # Convenient sugar after session has been created.
            # Responsible for resource freeing if we raise.
            if start_time:
                if start_time is True:
                    session.start_request()
                else:
                    session.start_time = start_time
            if isinstance(input, io.IOBase):
                session.input_stream = input
            elif input is not None:
                session.add_input_text(input, final=True)
        except:
            session.destruct()
            raise
        return session
 
    def redact(self, text:StringLike) -> StringLike:
        """
        Redact a buffer of text, according to the engine's configuration.
        """
        with EdkBuffer(api.engine.EdkRedactText, self, self._to_bytes(text)) as buffer:
            redacted = buffer.value
        if not self._is_bytes(text):
            redacted = redacted.decode('utf-8')
        return redacted

    def count_matches(self, text:StringLike) -> dict[StringLike,int]:
        """
        Count the number of matches in a buffer of text.
        """
        byte = self._is_bytes(text)
        with EdkMatchCounts(api.engine.EdkGetMatchCounts, self, self._to_bytes(text)) as counts:
            return {(name if byte else name.decode('utf-8')):int(count) for name,count in counts}

    @property
    def entities(self) -> set[str]:
        """
        The names of all public entities in the grammar(s) loaded by the engine.
        """
        with EdkStringArray(api.engine.EdkGetEntities, self) as strarr:
            return {e.decode('utf-8') for e in strarr}

    def load(self, *,
             grammar:Optional[StringLike]=None,
             grammarpath:Optional[PathToFile]=None,
             configpath:Optional[PathToFile]=None
             ) -> None:
        """
        Load a new grammar into the engine.
        May be verbatim XML source (`grammar=`) or a path to an XML or ECR file (`grammarpath=`).
        Can also supply a path to a compilation configuration JSON file to control compiler options.
        """
        if bool(grammar) == bool(grammarpath):
            raise TypeError("{}() requires exactly one of 'grammar', 'grammarpath'".format(self.load.__name__))
        if grammar:
            grammar = self._to_bytes(grammar)
            if not configpath:
                api.engine.EdkLoadResourceBuffer(self, grammar, len(grammar))
            else:
                api.engine.EdkLoadResourceBufferWithCompileConfig(self, grammar, len(grammar), self._to_bytes(configpath))
        else: # elif grammarpath
            if not configpath:
                api.engine.EdkLoadResourceFile(self, self._to_bytes(grammarpath))
            else:
                api.engine.EdkLoadResourceFileWithCompileConfig(self, self._to_bytes(grammarpath), self._to_bytes(configpath))

    def save(self, grammarpath:PathToFile) -> None:
        """
        Save the currently-loaded grammars to disk as a single ECR file.
        """
        api.engine.EdkSaveResourceFile(self, self._to_bytes(grammarpath))

    def add_target_entities(self, *entities:StringLike) -> None:
        """
        Enable one or more entities for matching.
        These must be names of public entities in a previously-loaded grammar.
        Wildcards are permitted (* and ?).
        """
        if entities:
            api.engine.EdkAddTargetEntity(self, b','.join(map(self._to_bytes, entities)))

    def add_post_processor(self,
                           luascript:PathToFile,
                           name:Optional[StringLike]=None,
                           entities:StringLike='*',
                           enmasse:bool=False
                           ) -> None:
        """
        Add a post-processing task to the engine configuration.
        """
        if not name: name = str(uuid.uuid4())
        api.engine.EdkEngineAddPostProcessingTask(self, self._to_bytes(name), self._to_bytes(luascript), self._to_bytes(entities), enmasse)

    @property
    def logger(self) -> Loggable:
        """
        Set a logger instance to receive messages logged by this engine and sessions it creates.
        `logger` should provide a `log()` method, for example those created by `logging.getLogger`.
        This attribute cannot be read, only assigned.
        """
        raise AttributeError("The `logger` attribute cannot be read; assign a value to set the log destination.")
    @logger.setter
    def logger(self, logger:Loggable) -> None:
        self._log_callback = callbacks.LoggingCallback(logger)
        api.engine.EdkSetLoggingCallback(self, self._log_callback)


class EdkFactory(EdkHandleBase):
    """
    The recommended way to create an engine and use the Eduction SDK.
    
    Your application's first call to the Eduction API should be to create a factory with
    :meth:`EdkFactory.create_with_license_key`, which requires you to supply a valid license key.

    As of the 23.2.0 release, Eduction licenses consist of two files:
     * your license key, commonly called `licensekey.dat`
     * a `versionkey.dat` file.

    In general the best way to use these two files together is to concatenate them with
    a semicolon character (';') as a separator.
    """
    _handletype = api.factory.EdkFactoryHandle
    _destructor = staticmethod(api.factory.EdkFactoryDestroy)
    __slots__ = ()

    @classmethod
    def create_with_license_key(cls, licensekey:StringLike) -> 'EdkFactory':
        """ Create a new factory. Supply the license key (+version key) as a single string. """
        return cls(api.factory.EdkFactoryCreateWithLicenseKey, ..., cls._to_bytes(licensekey))

    def engine(self, *,
               config:Optional[Configuration]=None,
               configpath:Optional[PathToFile]=None
               ) -> EdkEngine:
        """
        Create a new Eduction engine. May be preconfigured by supplying an in-memory configuration
        (a string or a ConfigParser instance), or a path to an on-disk configuration file.

        Alternatively, an empty engine can be created and configured "by hand" by loading grammar
        files and setting individual settings.
        """
        if configpath is None:
            if config is None:
                return EdkEngine(api.factory.EdkFactoryMakeEngine, self)
            else:
                return EdkEngine(api.factory.EdkFactoryMakeEngineFromConfigBuffer, self, ..., self._to_bytes(config))
        elif config is None:
            return EdkEngine(api.factory.EdkFactoryMakeEngineFromConfigFile, self, ..., self._to_bytes(configpath))
        else:
            raise TypeError("Cannot specify both 'config' and 'configpath'")

    @classmethod
    def read_license(cls, licensekey:StringLike) -> dict[str,str|int]:
        """ Decode the supplied license key and return a dictionary of licensing info """
        with EdkBuffer(api.generic.EdkGetLicenseInfo, cls._to_bytes(licensekey)) as buffer:
            info = buffer.value.decode('utf-8')
        return json.loads(info)
