###
# Copyright 2023 Open Text.
# 
# The only warranties for products and services of Open Text and its
# affiliates and licensors ("Open Text") are as may be set forth in the
# express warranty statements accompanying such products and services.
# Nothing herein should be construed as constituting an additional warranty.
# Open Text shall not be liable for technical or editorial errors or omissions
# contained herein. The information contained herein is subject to change
# without notice.
# 
# Except as specifically indicated otherwise, this document contains
# confidential information and a valid license is required for possession, use
# or copying. If this work is provided to the U.S. Government, consistent with
# FAR 12.211 and 12.212, Commercial Computer Software, Computer Software
# Documentation, and Technical Data for Commercial Items are licensed to the
# U.S. Government under vendor's standard commercial license.
###
__all__ = [
    'EdkError', 'EdkBool',
    'EdkLoggingFn', 'EdkInputProc',
    'EdkOffset',
    'EdkTime', 'EdkEpochTimeMilliseconds',
    'EdkCaseNormalization', 'EdkCaseNormalizationBehaviour', 'EdkAllowMultipleResults',
    'EDK_VERSION_INFO'
    ]


import datetime
import enum
import numbers

from ctypes import (c_bool, c_int, c_int32, c_int64, c_size_t,
                    c_char, c_char_p, c_void_p,
                    py_object, Structure, CFUNCTYPE)

from typing import TypeAlias


EdkError = c_int32
""" Error Codes are int32_t type """
EdkBool = c_bool
""" Boolean for EDK """

EdkLoggingFn = CFUNCTYPE(None, py_object, c_int, c_char_p)
"""
Logging function that is able to be specified on the engine structure, used 
when creating the post-processor on the session structure to log any Lua 
errors during postprocessing. Uses the internal logger of Eduction.

:param nLogLevel: (:class:`~ctypes.py_object`) The log level of the log message.
:param szFormat: (:class:`~ctypes.c_int`:) The string, possibly with format specifiers, to be used for the log message.
:param varargs: (:class:`~ctypes.c_char_p`) Varargs containing values to be used to replace any format specifiers in szFormat.
:returns: None
"""

EdkInputProc = CFUNCTYPE(c_size_t, c_void_p, c_size_t, c_size_t, py_object)
"""
Application-defined callback function used with the :any:`EdkSetInputStream` function.

:param bBuffer: (:class:`~ctypes.c_void_p`) A text buffer of minimum length ``nSize*nCount`` which the function should populate with data from the stream. This parameter is both input and output.
:param nSize: (:class:`~ctypes.c_size_t`) Item size in bytes.
:param nCount: (:class:`~ctypes.c_size_t`) Maximum number of items to be read.
:param hStream: (:class:`~ctypes.py_object`) The stream handle passed to :any:`EdkSetInputStream`.

:return: (:class:`~ctypes.c_size_t`) The number of characters read from the stream and placed into ``bBuffer``.

.. note:: 
    API users should implement this function and pass its address to :any:`EdkSetInputStream`.
    :any:`EdkInputProc` is called by the API whenever more data is required as a result of calling :any:`EdkGetNextMatch`.

.. seealso:: 
    :any:`EdkSetInputStream`, :any:`EdkAddInputText`
"""

class EdkOffset(Structure):
    """
    Represents an offset within an input buffer, providing both byte and codepoint (character) offsets.

    Fields:
        - ``bytes`` (:class:`~ctypes.c_size_t`): The offset in bytes.
        - ``codepoints`` (:class:`~ctypes.c_size_t`): The offset in Unicode codepoints (characters).
    """
    _fields_ = [
        ('bytes', c_size_t),
        ('codepoints', c_size_t)
    ]

class EdkTime(c_int64):
    """
    Alias for Unix time (time in seconds since January 1st, 1970).
    Can also represent more precise Unix time (time in milliseconds since January 1st, 1970) when subclassed appropriately.
    """
    value_annotation: TypeAlias = datetime.datetime|numbers.Number
    @classmethod
    def from_param(cls, obj: datetime.datetime|numbers.Integral):
        """
        Handles conversion from a datetime object or a numeric timestamp to an EdkTime object. """
        if isinstance(obj, datetime.datetime):
            obj = int(obj.timestamp() * getattr(cls, 'per_second', 1))
        elif isinstance(obj, numbers.Number) and not isinstance(obj, numbers.Integral):
            obj = int(obj)
        return c_int64.from_param(obj)  # Avoid super() bug

class EdkEpochTimeMilliseconds(EdkTime):
    """
    Alias for a more precise Unix time (time in milliseconds since January 1st, 1970).
    """
    per_second: float = 1e3
    ''' Determines the unit of time to use.  '''

class c_enum_base(enum.IntEnum):
    """
    Base class for enumeration types, providing a method for parameter conversion.
    """
    @classmethod
    def from_param(cls, param):
        """ Performs parameter conversion. """
        return cls(param)

class EdkCaseNormalization(c_enum_base):
    """
    Valid settings for EdkSetCaseNormalization.
    """
    CaseNormalizationOriginal = 0
    """ No case normalization applied (default). """
    CaseNormalizationUpper = 1
    """ Normalize to uppercase. """
    CaseNormalizationLower = 2
    """ Normalize to lowercase. """

class EdkCaseNormalizationBehaviour(c_enum_base):
    """
    Valid settings for EdkSetCaseNormalizationBehaviour.
    """
    NormalizationBehaviourNormal = 0
    """ Standard case normalization behavior. """
    NormalizationBehaviourTurkic = 1
    """
    Follow Turkic conventions for case normalization.
    """

class _c_enum_param_value:
    """
    Base class for enumeration types intended to be used as parameter values.
    """
    @property
    def _as_parameter_(self):
        return self.value

class EdkAllowMultipleResults(_c_enum_param_value, bytes, enum.Enum):
    """
    Enum to specify how multiple results should be handled.
    """
    AllowMultipleResultsAll = b"ALL"
    """ Allow all results. """
    AllowMultipleResultsNone = b"NO"
    """ Do not allow multiple results. """
    AllowMultipleResultsOnePerEntity = b"ONEPERENTITY"
    """ Allow only one result per entity. """

class EDK_VERSION_INFO(Structure):
    """
    Contains version information for the EDK library.

    Fields:
        - ``copyright`` (:class:`~ctypes.c_char` * 128): Copyright notice.
        - ``buildTime`` (:class:`~ctypes.c_char` * 128): GMT time of software build.
        - ``hostName`` (:class:`~ctypes.c_char` * 128): Reserved.
        - ``userName`` (:class:`~ctypes.c_char` * 128): Reserved.
        - ``versionString`` (:class:`~ctypes.c_char` * 16): Version string.
        - ``vMajor`` (:class:`~ctypes.c_int32`): Major version number.
        - ``vMinor`` (:class:`~ctypes.c_int32`): Minor version number.
        - ``vChangeSet`` (:class:`~ctypes.c_int32`): Change Set. Provided only in official releases. Specific build number.
    """
    _fields_ = [
        ('copyright', c_char * 128),
        ('buildTime', c_char * 128),
        ('hostName', c_char * 128),
        ('userName', c_char * 128),
        ('versionString', c_char * 16),
        ('vMajor', c_int32),
        ('vMinor', c_int32),
        ('vChangeSet', c_int32)
    ]
